﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Collections;

namespace ExpenseTracker
{
    public partial class MainWindow : Window
    {
        ArrayList expenses = new ArrayList();
        int maxEntries = 100;

        public MainWindow()
        {
            InitializeComponent();
        }

        private void AddExpense_Click(object sender, RoutedEventArgs e)
        {
            if (expenses.Count >= maxEntries)
            {
                MessageBox.Show("Maximum number of expense entries reached.");
                return;
            }

            string date = dateTextBox.Text;
            string category = categoryTextBox.Text;
            string amount = amountTextBox.Text;
            string description = descriptionTextBox.Text;

            if (string.IsNullOrWhiteSpace(date) || string.IsNullOrWhiteSpace(category) ||
                string.IsNullOrWhiteSpace(amount) || string.IsNullOrWhiteSpace(description))
            {
                MessageBox.Show("Please fill in all fields.");
                return;
            }

            string[] entry = { date, category, amount, description };
            expenses.Add(entry);

            expenseListBox.Items.Add($"{date} | {category} | {amount} | {description}");

            // Clear inputs
            dateTextBox.Clear();
            categoryTextBox.Clear();
            amountTextBox.Clear();
            descriptionTextBox.Clear();
        }

        private void ViewSummary_Click(object sender, RoutedEventArgs e)
        {
            double total = 0;
            int count = 0;
            Hashtable categoryCounts = new Hashtable();

            foreach (string[] entry in expenses)
            {
                if (double.TryParse(entry[2], out double amount))
                {
                    total += amount;
                    count++;

                    string category = entry[1];
                    if (categoryCounts.ContainsKey(category))
                        categoryCounts[category] = (int)categoryCounts[category] + 1;
                    else
                        categoryCounts[category] = 1;
                }
            }

            double average = count > 0 ? total / count : 0;
            string mostFrequentCategory = categoryCounts.Count > 0
                ? (string)categoryCounts.Cast<DictionaryEntry>().OrderByDescending(k => k.Value).First().Key
                : "N/A";

            summaryTextBlock.Text = $"Total Expenses: {total:C}\n" +
                                    $"Average Expense: {average:C}\n" +
                                    $"Most Frequent Category: {mostFrequentCategory}";
        }

        private void Search_Click(object sender, RoutedEventArgs e)
        {
            string searchDate = dateTextBox.Text.Trim();
            string searchCategory = categoryTextBox.Text.Trim();
            expenseListBox.Items.Clear();

            foreach (string[] entry in expenses)
            {
                bool matchDate = !string.IsNullOrEmpty(searchDate) && entry[0] == searchDate;
                bool matchCategory = !string.IsNullOrEmpty(searchCategory) && entry[1] == searchCategory;

                if (matchDate || matchCategory)
                {
                    expenseListBox.Items.Add($"{entry[0]} | {entry[1]} | {entry[2]} | {entry[3]}");
                }
            }

            if (expenseListBox.Items.Count == 0)
            {
                MessageBox.Show("No matching entries found.");
            }
        }

        private void Delete_Click(object sender, RoutedEventArgs e)
        {
            if (expenseListBox.SelectedIndex >= 0)
            {
                expenses.RemoveAt(expenseListBox.SelectedIndex);
                expenseListBox.Items.RemoveAt(expenseListBox.SelectedIndex);
            }
            else
            {
                MessageBox.Show("Please select an entry to delete.");
            }
        }
    }
}
