﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

using ContactManagementSystem.Models;

namespace ContactManagementSystem
{
    public partial class MainWindow : Window
    {
        ArrayList Contacts = new ArrayList();

        public MainWindow()
        {
            InitializeComponent();
            contactsListBox.ItemsSource = Contacts;
        }

        private void AddContact_Click(object sender, RoutedEventArgs e)
        {
            string name = nameTextBox.Text;
            string phone = phoneTextBox.Text;
            string email = emailTextBox.Text;

            if (!string.IsNullOrWhiteSpace(name) && !string.IsNullOrWhiteSpace(phone) && !string.IsNullOrWhiteSpace(email))
            {
                Contact newContact = new Contact(name, phone, email);
                Contacts.Add(newContact);
                contactsListBox.Items.Refresh();
                ClearInputFields();
            }
            else
            {
                MessageBox.Show("Please fill all fields.");
            }
        }

        private void EditContact_Click(object sender, RoutedEventArgs e)
        {
            if (contactsListBox.SelectedItem is Contact selectedContact)
            {
                selectedContact.Name = nameTextBox.Text;
                selectedContact.PhoneNumber = phoneTextBox.Text;
                selectedContact.Email = emailTextBox.Text;
                contactsListBox.Items.Refresh();
                ClearInputFields();
            }
            else
            {
                MessageBox.Show("Please select a contact to edit.");
            }
        }

        private void DeleteContact_Click(object sender, RoutedEventArgs e)
        {
            if (contactsListBox.SelectedItem is Contact selectedContact)
            {
                Contacts.Remove(selectedContact);
                contactsListBox.Items.Refresh();
                ClearInputFields();
            }
            else
            {
                MessageBox.Show("Please select a contact to delete.");
            }
        }

        private void ContactsListBox_SelectionChanged(object sender, System.Windows.Controls.SelectionChangedEventArgs e)
        {
            if (contactsListBox.SelectedItem is Contact selectedContact)
            {
                nameTextBox.Text = selectedContact.Name;
                phoneTextBox.Text = selectedContact.PhoneNumber;
                emailTextBox.Text = selectedContact.Email;
            }
        }

        private void ClearInputFields()
        {
            nameTextBox.Clear();
            phoneTextBox.Clear();
            emailTextBox.Clear();
        }
    }
}
