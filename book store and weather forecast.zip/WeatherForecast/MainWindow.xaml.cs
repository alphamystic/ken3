﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System;
using System.Text;
using System.Windows;

namespace WeatherForecast
{
    public partial class MainWindow : Window
    {
        private Random random = new Random();

        public MainWindow()
        {
            InitializeComponent();
        }

        private void btnGenerate_Click(object sender, RoutedEventArgs e)
        {
            txtForecast.Clear();

            for (int i = 1; i <= 7; i++)
            {
                int temperature = GenerateRandomTemperature();
                string condition = DetermineWeatherCondition(temperature);

                string forecast = $"Day {i}: Temperature is {temperature}, Weather is {condition}";
                txtForecast.AppendText(forecast + Environment.NewLine);
            }
        }

        private int GenerateRandomTemperature()
        {
            return random.Next(-10, 36); // inclusive -10 to 35
        }

        private string DetermineWeatherCondition(int temperature)
        {
            if (temperature < 0)
            {
                return "Snowy";
            }
            else if (temperature <= 15)
            {
                return "Rainy";
            }
            else if (temperature <= 25)
            {
                return "Cloudy";
            }
            else
            {
                return "Sunny";
            }
        }
    }
}

