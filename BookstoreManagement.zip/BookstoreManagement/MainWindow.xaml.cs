﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Collections;


namespace BookstoreManagement
{
    public partial class MainWindow : Window
    {
        ArrayList bookstore = new ArrayList();

        public MainWindow()
        {
            InitializeComponent();
        }

        private void btnAdd_Click(object sender, RoutedEventArgs e)
        {
            string title = txtTitle.Text.Trim();
            string author = txtAuthor.Text.Trim();
            string isbn = txtISBN.Text.Trim();
            string quantityText = txtQuantity.Text.Trim();

            if (!ValidateInputs(title, author, isbn, quantityText, out int quantity))
                return;

            foreach (string[] book in bookstore)
            {
                if (book[2] == isbn)
                {
                    MessageBox.Show("A book with this ISBN already exists.", "Duplicate ISBN", MessageBoxButton.OK, MessageBoxImage.Warning);
                    return;
                }
            }

            string[] newBook = { title, author, isbn, quantity.ToString() };
            bookstore.Add(newBook);
            MessageBox.Show("Book added successfully!", "Success", MessageBoxButton.OK, MessageBoxImage.Information);

            ClearInputs();
        }

        private void btnUpdate_Click(object sender, RoutedEventArgs e)
        {
            string isbn = txtISBN.Text.Trim();
            string quantityText = txtQuantity.Text.Trim();

            if (string.IsNullOrWhiteSpace(isbn))
            {
                MessageBox.Show("Enter an ISBN to update.", "Missing ISBN", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            if (!int.TryParse(quantityText, out int quantity) || quantity < 0)
            {
                MessageBox.Show("Quantity must be a non-negative number.", "Invalid Quantity", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            foreach (string[] book in bookstore)
            {
                if (book[2] == isbn)
                {
                    book[3] = quantity.ToString();
                    MessageBox.Show("Quantity updated successfully!", "Updated", MessageBoxButton.OK, MessageBoxImage.Information);
                    return;
                }
            }

            MessageBox.Show("Book not found.", "Not Found", MessageBoxButton.OK, MessageBoxImage.Information);
        }

        private void btnSearch_Click(object sender, RoutedEventArgs e)
        {
            string query = txtISBN.Text.Trim();
            if (string.IsNullOrWhiteSpace(query))
            {
                MessageBox.Show("Enter ISBN, Title or Author to search.", "Missing Search Term", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            foreach (string[] book in bookstore)
            {
                if (book[2].Equals(query, StringComparison.OrdinalIgnoreCase) ||
                    book[0].IndexOf(query, StringComparison.OrdinalIgnoreCase) >= 0 ||
                    book[1].IndexOf(query, StringComparison.OrdinalIgnoreCase) >= 0)
                {
                    txtTitle.Text = book[0];
                    txtAuthor.Text = book[1];
                    txtISBN.Text = book[2];
                    txtQuantity.Text = book[3];

                    MessageBox.Show("Book found!", "Success", MessageBoxButton.OK, MessageBoxImage.Information);
                    return;
                }
            }

            MessageBox.Show("Book not found.", "Not Found", MessageBoxButton.OK, MessageBoxImage.Information);
        }

        private void btnDelete_Click(object sender, RoutedEventArgs e)
        {
            string isbn = txtISBN.Text.Trim();
            if (string.IsNullOrWhiteSpace(isbn))
            {
                MessageBox.Show("Enter an ISBN to delete.", "Missing ISBN", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            for (int i = 0; i < bookstore.Count; i++)
            {
                string[] book = (string[])bookstore[i];
                if (book[2] == isbn)
                {
                    bookstore.RemoveAt(i);
                    MessageBox.Show("Book deleted successfully!", "Deleted", MessageBoxButton.OK, MessageBoxImage.Information);
                    ClearInputs();
                    return;
                }
            }

            MessageBox.Show("Book not found.", "Not Found", MessageBoxButton.OK, MessageBoxImage.Information);
        }

        private void btnViewAll_Click(object sender, RoutedEventArgs e)
        {
            listBooks.Items.Clear();

            if (bookstore.Count == 0)
            {
                listBooks.Items.Add("No books available.");
                return;
            }

            foreach (string[] book in bookstore)
            {
                listBooks.Items.Add($"Title: {book[0]}, Author: {book[1]}, ISBN: {book[2]}, Quantity: {book[3]}");
            }
        }

        private bool ValidateInputs(string title, string author, string isbn, string quantityText, out int quantity)
        {
            quantity = 0;
            if (string.IsNullOrWhiteSpace(title) || string.IsNullOrWhiteSpace(author) ||
                string.IsNullOrWhiteSpace(isbn) || string.IsNullOrWhiteSpace(quantityText))
            {
                MessageBox.Show("Please fill in all fields.", "Missing Fields", MessageBoxButton.OK, MessageBoxImage.Warning);
                return false;
            }

            if (!int.TryParse(quantityText, out quantity) || quantity <= 0)
            {
                MessageBox.Show("Quantity must be a positive number.", "Invalid Quantity", MessageBoxButton.OK, MessageBoxImage.Warning);
                return false;
            }

            return true;
        }

        private void ClearInputs()
        {
            txtTitle.Clear();
            txtAuthor.Clear();
            txtISBN.Clear();
            txtQuantity.Clear();
        }
    }
}
