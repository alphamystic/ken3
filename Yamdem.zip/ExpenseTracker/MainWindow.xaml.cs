﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace ExpenseTracker
{
    public partial class MainWindow : Window
    {
        // ArrayList to store expense entries (each as a string array: [date, category, amount, description])
        ArrayList expenseRecords = new ArrayList();
        int maxEntries = 100;

        public MainWindow()
        {
            InitializeComponent();
        }

        // Adds a new expense entry
        private void AddExpense_Click(object sender, RoutedEventArgs e)
        {
            if (expenseRecords.Count >= maxEntries)
            {
                MessageBox.Show("Maximum number of expense entries reached.");
                return;
            }

            string date = dateInput.Text.Trim();
            string category = categoryInput.Text.Trim();
            string amount = amountInput.Text.Trim();
            string description = descriptionInput.Text.Trim();

            if (string.IsNullOrWhiteSpace(date) || string.IsNullOrWhiteSpace(category) ||
                string.IsNullOrWhiteSpace(amount) || string.IsNullOrWhiteSpace(description))
            {
                MessageBox.Show("Please fill in all fields.");
                return;
            }

            // Create a new entry and add it to the ArrayList
            string[] entry = { date, category, amount, description };
            expenseRecords.Add(entry);

            // Add the entry to the ListBox for display
            expenseListBox.Items.Add($"{date} | {category} | {amount} | {description}");

            // Clear input fields
            dateInput.Clear();
            categoryInput.Clear();
            amountInput.Clear();
            descriptionInput.Clear();
        }

        // Displays summary statistics: total, average, and most frequent category
        private void ViewSummary_Click(object sender, RoutedEventArgs e)
        {
            double total = 0;
            int count = 0;
            Hashtable categoryCounts = new Hashtable();

            foreach (string[] entry in expenseRecords)
            {
                if (double.TryParse(entry[2], out double amount))
                {
                    total += amount;
                    count++;

                    string category = entry[1];
                    if (categoryCounts.ContainsKey(category))
                        categoryCounts[category] = (int)categoryCounts[category] + 1;
                    else
                        categoryCounts[category] = 1;
                }
            }

            double average = count > 0 ? total / count : 0;
            string mostFrequentCategory = categoryCounts.Count > 0
                ? (string)categoryCounts.Cast<DictionaryEntry>().OrderByDescending(k => k.Value).First().Key
                : "N/A";

            summaryTextBlock.Text = $"Total Expenses: {total:C}\n" +
                                    $"Average Expense: {average:C}\n" +
                                    $"Most Frequent Category: {mostFrequentCategory}";
        }

        // Searches for expenses by date or category
        private void Search_Click(object sender, RoutedEventArgs e)
        {
            string searchDate = dateInput.Text.Trim();
            string searchCategory = categoryInput.Text.Trim();
            expenseListBox.Items.Clear();

            foreach (string[] entry in expenseRecords)
            {
                bool matchDate = !string.IsNullOrEmpty(searchDate) && entry[0].Equals(searchDate, StringComparison.OrdinalIgnoreCase);
                bool matchCategory = !string.IsNullOrEmpty(searchCategory) && entry[1].Equals(searchCategory, StringComparison.OrdinalIgnoreCase);

                if (matchDate || matchCategory)
                {
                    expenseListBox.Items.Add($"{entry[0]} | {entry[1]} | {entry[2]} | {entry[3]}");
                }
            }

            if (expenseListBox.Items.Count == 0)
            {
                MessageBox.Show("No matching expense found.");
            }
        }

        // Deletes the selected expense entry
        private void Delete_Click(object sender, RoutedEventArgs e)
        {
            int selectedIndex = expenseListBox.SelectedIndex;

            if (selectedIndex >= 0 && selectedIndex < expenseRecords.Count)
            {
                expenseRecords.RemoveAt(selectedIndex);
                expenseListBox.Items.RemoveAt(selectedIndex);
                MessageBox.Show("Selected expense deleted.");
            }
            else
            {
                MessageBox.Show("Please select an expense to delete.");
            }
        }

        // Lists all stored expense entries
        private void ListAll_Click(object sender, RoutedEventArgs e)
        {
            expenseListBox.Items.Clear();

            foreach (string[] entry in expenseRecords)
            {
                expenseListBox.Items.Add($"{entry[0]} | {entry[1]} | {entry[2]} | {entry[3]}");
            }
        }
    }
}
