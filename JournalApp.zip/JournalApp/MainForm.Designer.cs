﻿using System.Windows.Forms;
using System.Drawing;

namespace JournalApp
{
    partial class MainForm
    {
        private System.ComponentModel.IContainer components = null;
        private DateTimePicker datePicker;
        private TextBox entryTextBox;
        private ListBox entryListBox;
        private Button addButton;
        private Button editButton;
        private Button deleteButton;
        private Button saveButton;
        private Button loadButton;
        private TableLayoutPanel mainLayout;
        private TableLayoutPanel rightButtonLayout;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null)) components.Dispose();
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            datePicker = new DateTimePicker();
            entryTextBox = new TextBox();
            entryListBox = new ListBox();
            addButton = new Button();
            editButton = new Button();
            deleteButton = new Button();
            saveButton = new Button();
            loadButton = new Button();
            mainLayout = new TableLayoutPanel();
            rightButtonLayout = new TableLayoutPanel();

            // MainForm
            this.ClientSize = new Size(1000, 700);
            this.MinimumSize = new Size(800, 600);
            this.Text = "📘 Daily Journal";
            this.Font = new Font("Segoe UI", 12F);
            this.BackColor = Color.White;

            // Main Layout
            mainLayout.Dock = DockStyle.Fill;
            mainLayout.ColumnCount = 2;
            mainLayout.RowCount = 3;
            mainLayout.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 80F));
            mainLayout.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 20F));
            mainLayout.RowStyles.Add(new RowStyle(SizeType.Absolute, 50F));
            mainLayout.RowStyles.Add(new RowStyle(SizeType.Percent, 70F));
            mainLayout.RowStyles.Add(new RowStyle(SizeType.Percent, 30F));
            this.Controls.Add(mainLayout);

            // DatePicker
            datePicker.Dock = DockStyle.Fill;
            datePicker.Font = new Font("Segoe UI", 13F);
            datePicker.Margin = new Padding(10, 10, 10, 5);
            mainLayout.SetColumnSpan(datePicker, 2);
            mainLayout.Controls.Add(datePicker, 0, 0);

            // Entry TextBox (Editor)
            entryTextBox.Dock = DockStyle.Fill;
            entryTextBox.Multiline = true;
            entryTextBox.ScrollBars = ScrollBars.Vertical;
            entryTextBox.Margin = new Padding(10, 5, 10, 5);
            entryTextBox.Font = new Font("Segoe UI", 14F);
            entryTextBox.BackColor = Color.WhiteSmoke;
            entryTextBox.ForeColor = Color.Black;
            entryTextBox.BorderStyle = BorderStyle.FixedSingle;
            mainLayout.Controls.Add(entryTextBox, 0, 1);

            // Right Button Panel
            rightButtonLayout.Dock = DockStyle.Fill;
            rightButtonLayout.ColumnCount = 1;
            rightButtonLayout.RowCount = 5;
            for (int i = 0; i < 5; i++)
                rightButtonLayout.RowStyles.Add(new RowStyle(SizeType.Percent, 20F));
            rightButtonLayout.Margin = new Padding(10, 5, 10, 5);
            mainLayout.Controls.Add(rightButtonLayout, 1, 1);

            // Buttons
            var buttons = new[] { addButton, editButton, deleteButton, saveButton, loadButton };
            string[] texts = { "➕ Add", "✏️ Edit", "🗑️ Delete", "💾 Save", "📂 Load" };
            for (int i = 0; i < buttons.Length; i++)
            {
                var btn = buttons[i];
                btn.Text = texts[i];
                btn.Dock = DockStyle.Fill;
                btn.Font = new Font("Segoe UI", 12F, FontStyle.Bold);
                btn.Margin = new Padding(5);
                btn.BackColor = Color.LightSteelBlue;
                btn.FlatStyle = FlatStyle.Flat;
                btn.FlatAppearance.BorderSize = 0;
                rightButtonLayout.Controls.Add(btn, 0, i);
            }

            // Entry ListBox
            entryListBox.Dock = DockStyle.Fill;
            entryListBox.Margin = new Padding(10);
            entryListBox.Font = new Font("Segoe UI", 12F);
            mainLayout.SetColumnSpan(entryListBox, 2);
            mainLayout.Controls.Add(entryListBox, 0, 2);

            this.ResumeLayout(false);
        }
    }
}
