using System;
using System.Collections;
using System.Windows.Forms;

namespace JournalApp
{
    public partial class MainForm : Form
    {
        private ArrayList journalEntries = new ArrayList();

        public MainForm()
        {
            InitializeComponent();
            this.WindowState = FormWindowState.Maximized;

            // Hook event handlers
            addButton.Click += AddButton_Click;
            editButton.Click += EditButton_Click;
            deleteButton.Click += DeleteButton_Click;
            saveButton.Click += SaveButton_Click;
            loadButton.Click += LoadButton_Click;
            entryListBox.SelectedIndexChanged += EntryListBox_SelectedIndexChanged;
        }

        private void AddButton_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(entryTextBox.Text))
            {
                MessageBox.Show("Please enter your journal text.", "Empty Entry", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            JournalEntry entry = new JournalEntry
            {
                Date = datePicker.Value,
                Text = entryTextBox.Text.Trim()
            };

            journalEntries.Add(entry);
            entryListBox.Items.Add(entry);
            entryTextBox.Clear(); // Clear editor after adding
        }

        private void EditButton_Click(object sender, EventArgs e)
        {
            if (entryListBox.SelectedItem is JournalEntry selected)
            {
                selected.Date = datePicker.Value;
                selected.Text = entryTextBox.Text.Trim();

                int idx = entryListBox.SelectedIndex;
                entryListBox.Items[idx] = null;     // Force refresh
                entryListBox.Items[idx] = selected; // Reassign
            }
        }

        private void DeleteButton_Click(object sender, EventArgs e)
        {
            if (entryListBox.SelectedItem is JournalEntry selected)
            {
                var result = MessageBox.Show("Are you sure you want to delete this entry?", "Confirm Delete", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
                if (result == DialogResult.Yes)
                {
                    journalEntries.Remove(selected);
                    entryListBox.Items.Remove(selected);
                    entryTextBox.Clear();
                }
            }
        }

        private void SaveButton_Click(object sender, EventArgs e)
        {
            using (SaveFileDialog sfd = new SaveFileDialog
            {
                Filter = "JSON Files|*.json",
                Title = "Save Journal"
            })
            {
                if (sfd.ShowDialog() == DialogResult.OK)
                    Utils.SaveToFile(sfd.FileName, journalEntries);
            }
        }

        private void LoadButton_Click(object sender, EventArgs e)
        {
            using (OpenFileDialog ofd = new OpenFileDialog
            {
                Filter = "JSON Files|*.json",
                Title = "Open Journal"
            })
            {
                if (ofd.ShowDialog() == DialogResult.OK)
                {
                    journalEntries = Utils.LoadFromFile(ofd.FileName);
                    entryListBox.Items.Clear();
                    foreach (JournalEntry entry in journalEntries)
                        entryListBox.Items.Add(entry);
                }
            }
        }

        private void EntryListBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (entryListBox.SelectedItem is JournalEntry selected)
            {
                datePicker.Value = selected.Date;
                entryTextBox.Text = selected.Text;
            }
        }
    }
}
