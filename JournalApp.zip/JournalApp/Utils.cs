using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Text.Json;

namespace JournalApp
{
    public static class Utils
    {
        public static void SaveToFile(string path, ArrayList entries)
        {
            var json = JsonSerializer.Serialize(entries);
            File.WriteAllText(path, json);
        }

        public static ArrayList LoadFromFile(string path)
        {
            var json = File.ReadAllText(path);
            var list = JsonSerializer.Deserialize<List<JournalEntry>>(json);
            return new ArrayList(list ?? new List<JournalEntry>());
        }
    }
}
