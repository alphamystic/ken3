using System;

namespace JournalApp
{
    [Serializable]
    public class JournalEntry
    {
        public DateTime Date { get; set; }
        public string Text { get; set; }

        public override string ToString()
        {
            if (string.IsNullOrWhiteSpace(Text))
                return $"{Date.ToShortDateString()} - (Empty Entry)";
            return $"{Date.ToShortDateString()} - {Text.Substring(0, Math.Min(Text.Length, 30))}...";
        }
    }
}
