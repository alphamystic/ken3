package entities

import (
	"hospwebapp/lib/utils"
)

type Invoice struct {
	ID         int
	InvoiceID  string
	PatientID  string
	Amount     float64
	Paid       string
	utils.TimeStamps
	PatientData *Patient
}
