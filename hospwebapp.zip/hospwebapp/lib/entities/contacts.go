package entities

import (
	"hospwebapp/lib/utils"
)

//Can be implemented to create a contact us
type ContactUs struct {
	CuID    string
	Name    string
	Email   string
	Subject string
	Message string
	Handled bool
	utils.TimeStamps
}
