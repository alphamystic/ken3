package entities

import (
	//"time"
	"hospwebapp/lib/utils"
)

type Appointment struct {
	ID               int
	AppointmentID    string `json: "appointment_id"`
	Name             string `json: "name"`
	Email            string `json: "email"`
	Number           string `json: "number"`
	Reason           string `json: "reason"`
	Message          string `json: "message"`
	AppointmentTime  string `json: "appointment_time"`
	Status           string `json: "status"` // "Pending", "Postponed", "Handled"
	utils.TimeStamps
}
