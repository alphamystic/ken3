package entities

import (
	"time"
	"hospwebapp/lib/utils"
)

type Patient struct {
	ID            int
	UUID          string `json: "patient_id"`
	FullName      string `json: "Full Name"`
	Email         string `json: "email"`
	ContactNumber string `json: "number"`
	DateOfBirth   time.Time `json: "dateofbirth"`
	Gender        string `json: "gender"`
	Address       string `json: "address"`
	utils.TimeStamps
}

type PatientRecord struct {
	ID        int
	RecordID  string `json: "record_id"`
	PatientID string `json: "patient_id"`
	Record    string `json: "record"`
	UpdatedBy string `json: "updated_by"`
	DoctorName string `json: "doctor_name"`
	Status    string `json: "status"` //'Under Medication','Healed','Not Diagnosed'
	utils.TimeStamps
}
