package entities

import (
	"hospwebapp/lib/utils"
)

//Holds the User Data struct

type User struct {
	ID           int
	UserID       string
	Username     string
	Phone					string
	Password string
	Email        string
	Role         string //('Doctor','Receptionist','Patient','Admin')
	Gender       string
	utils.TimeStamps
}


type DoctorType struct {
	NameType  string
	utils.TimeStamps
}
