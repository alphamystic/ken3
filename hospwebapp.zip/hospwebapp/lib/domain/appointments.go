package domain

import (
	"fmt"
	"errors"
	"database/sql"
	"hospwebapp/lib/utils"
	ent "hospwebapp/lib/entities"

	_ "github.com/go-sql-driver/mysql"
)


// FUnction to create appointments.
func (dom *Domain) CreateAppointment(app ent.Appointment) error {
	var ins *sql.Stmt
	ins, err := dom.Dbs.Prepare(InsertAppointmentQuery)
	if err != nil {
		e := utils.LogErrorToFile("sql", fmt.Sprintf("Error Preparing to create appointments: %s", err))
		utils.Logerror(e)
		return errors.New("Server encountered an error while creating appointments, Try again later :).")
	}
	defer ins.Close()
	res, err := ins.Exec(app.AppointmentID, app.Name, app.Email, app.Number, app.Reason, app.Message, app.AppointmentTime, app.Status, app.CreatedAt, app.UpdatedAt)
	if err != nil {
		e := utils.LogErrorToFile("sql", fmt.Sprintf("Error executing insert appointment: %s", err))
		utils.Logerror(e)
		return errors.New("Error creating appintment while executing.")
	}
	rowsAffec, _ := res.RowsAffected()
	if err != nil || rowsAffec != 1 {
		e := utils.LogErrorToFile("sql", fmt.Sprintf("Error creating appointment, more than one row afffected: %s", err))
		utils.Logerror(e)
		return errors.New("Server encountered an error while creating appointment.")
	}
	return nil
}


// FUnction to ListAppintments by status
func (dom *Domain) ListAppointmentsByStatus(status string) ([]ent.Appointment,error){
	rows, err := dom.Dbs.Query(ListAppointmentsQuery,status)
	if err != nil {
		e := utils.LogErrorToFile("sql", fmt.Sprintf("Error listing appointments: %s", err))
		utils.Logerror(e)
		return nil, errors.New("Server encountered an error while listing all appointments.")
	}
	defer rows.Close()
	var appointments []ent.Appointment
	for rows.Next() {
		var app ent.Appointment
		err = rows.Scan(&app.AppointmentID, &app.Name, &app.Email, &app.Number, &app.Reason, &app.Message, &app.AppointmentTime, &app.Status, &app.CreatedAt, &app.UpdatedAt)
		if err != nil {
			e := utils.LogErrorToFile("sql", fmt.Sprintf("Error scanning for appointments: %s", err))
			utils.Logerror(e)
			return nil, errors.New("Server encountered an error while listing all appointments.")
		}
		appointments = append(appointments, app)
	}
	return appointments, nil
}


/// Function to list appointments by reason
func (dom *Domain) ListAppointmentsByReason(reason string) ([]ent.Appointment,error){
	rows, err := dom.Dbs.Query(ListAppointmentsReasonQuery,reason)
	if err != nil {
		e := utils.LogErrorToFile("sql", fmt.Sprintf("Error listing appointments: %s", err))
		utils.Logerror(e)
		return nil, errors.New("Server encountered an error while listing all appointments.")
	}
	defer rows.Close()
	var appointments []ent.Appointment
	for rows.Next() {
		var app ent.Appointment
		err = rows.Scan(&app.AppointmentID, &app.Name, &app.Email, &app.Number, &app.Reason, &app.Message, &app.AppointmentTime, &app.Status, &app.CreatedAt, &app.UpdatedAt)
		if err != nil {
			e := utils.LogErrorToFile("sql", fmt.Sprintf("Error scanning for appointments: %s", err))
			utils.Logerror(e)
			return nil, errors.New("Server encountered an error while listing all appointments.")
		}
		appointments = append(appointments, app)
	}
	return appointments, nil
}


// List appointments by a given status and reason.
func (dom *Domain) ListAppointmentsByReasonAndStatus(status,reason string) ([]ent.Appointment,error){
	rows, err := dom.Dbs.Query(ListAppintmentsReasonStatusQuery, status, reason)
	if err != nil {
		e := utils.LogErrorToFile("sql", fmt.Sprintf("Error listing appointments: %s", err))
		utils.Logerror(e)
		return nil, errors.New("Server encountered an error while listing all appointments.")
	}
	defer rows.Close()
	var appointments []ent.Appointment
	for rows.Next() {
		var app ent.Appointment
		err = rows.Scan(&app.AppointmentID, &app.Name, &app.Email, &app.Number, &app.Reason, &app.Message, &app.AppointmentTime, &app.Status, &app.CreatedAt, &app.UpdatedAt)
		if err != nil {
			e := utils.LogErrorToFile("sql", fmt.Sprintf("Error scanning for appointments: %s", err))
			utils.Logerror(e)
			return nil, errors.New("Server encountered an error while listing all appointments.")
		}
		appointments = append(appointments, app)
	}
	return appointments, nil
}

// FUnction to View An Appointment
func (dom *Domain) ViewAppointment(appointment_id string) (*ent.Appointment, error) {
	var app ent.Appointment
	row := dom.Dbs.QueryRow(ViewAppointmentQuery, appointment_id)
	err := row.Scan(&app.AppointmentID, &app.Name, &app.Email, &app.Number, &app.Reason, &app.Message, &app.AppointmentTime, &app.Status, &app.CreatedAt, &app.UpdatedAt)
	if err != nil {
		e := utils.LogErrorToFile("sql", fmt.Sprintf("Error viewing appointment with id %s %s", appointment_id, err))
		utils.Logerror(e)
		return nil, errors.New(fmt.Sprintf("Server encountered an error while viewing appointment with id of %s", appointment_id))
	}
	return &app, nil
}


// function to update appointment
func (dom *Domain) UpdateAppointment(app ent.Appointment) error {
  stmt,err := dom.Dbs.Prepare(UpdateAppointmentQuery)
  if err != nil{
    e := utils.LogErrorToFile("sql",fmt.Sprintf("Error preparing to update appointment: %s",err))
    utils.Logerror(e)
    return errors.New("Server encountered an error while updating appointment.")
  }
  defer stmt.Close()
  var res sql.Result
  res,err = stmt.Exec(&app.AppointmentID, &app.Name, &app.Email, &app.Number, &app.Reason, &app.Message, &app.AppointmentTime, &app.Status, &app.CreatedAt, &app.UpdatedAt)
  rowsAffec,_ := res.RowsAffected()
  if err != nil || rowsAffec != 1 {
    e := utils.LogErrorToFile("sql",fmt.Sprintf("Error updating appointment with id: %s. %s",&app.AppointmentID,err))
    utils.Logerror(e)
    return errors.New("Server encountered an error while updating appointment.")
  }
  return nil
}

func (dom *Domain) UpdateAppointmentAsHandled(status,appointment_id string) error {
  stmt,err := dom.Dbs.Prepare(UpdateAppointmentAsHandledQuery)
  if err != nil{
    e := utils.LogErrorToFile("sql",fmt.Sprintf("Error preparing to update appointment: %s",err))
    utils.Logerror(e)
    return errors.New("Server encountered an error while updating appointment.")
  }
  defer stmt.Close()
  var res sql.Result
  res,err = stmt.Exec(status,appointment_id)
  rowsAffec,_ := res.RowsAffected()
  if err != nil || rowsAffec != 1 {
    e := utils.LogErrorToFile("sql",fmt.Sprintf("Error updating appointment with id: %s. %s", appointment_id,err))
    utils.Logerror(e)
    return errors.New("Server encountered an error while updating appointment.")
  }
  return nil
}

func (dom *Domain) RescheduleAppointment(uuid, newTime string) error {
	stmt, err := dom.Dbs.Prepare(UpdateAppointmentTimeQuery)
	if err != nil {
		e := utils.LogErrorToFile("sql", fmt.Sprintf("Error preparing reschedule statement: %s", err))
		utils.Logerror(e)
		return errors.New("Server encountered an error while preparing reschedule operation.")
	}
	defer stmt.Close()

	res, err := stmt.Exec(newTime, uuid)
	if err != nil {
		e := utils.LogErrorToFile("sql", fmt.Sprintf("Error executing reschedule for uuid: %s. %s", uuid, err))
		utils.Logerror(e)
		return errors.New("Server encountered an error while updating appointment time.")
	}

	rowsAffec, _ := res.RowsAffected()
	if rowsAffec != 1 {
		e := utils.LogErrorToFile("sql", fmt.Sprintf("No appointment updated for uuid: %s", uuid))
		utils.Logerror(e)
		return errors.New("No appointment found or time was not updated.")
	}

	return nil
}



// FUnction to delete an appintment
func (dom *Domain) DeleteAppointment(appointment_id string) error{return nil}
