package domain

/* Invoice functionalities module */

import (
	"fmt"
	"errors"
	"database/sql"
	"hospwebapp/lib/utils"
	ent "hospwebapp/lib/entities"

	_ "github.com/go-sql-driver/mysql"
)


func (dom *Domain) CreateInvoice(invoice ent.Invoice) error {
	var ins *sql.Stmt
	ins, err := dom.Dbs.Prepare(InsertInvoiceQuery)
	if err != nil {
		e := utils.LogErrorToFile("sql", fmt.Sprintf("Error Preparing to create invoice: %s", err))
		utils.Logerror(e)
		return errors.New("Server encountered an error while creating invoice, Try again later :).")
	}
	defer ins.Close()
	res, err := ins.Exec(invoice.InvoiceID, invoice.PatientID, invoice.Amount, invoice.Paid, invoice.CreatedAt, invoice.UpdatedAt)
	if err != nil {
		e := utils.LogErrorToFile("sql", fmt.Sprintf("Error executing insert patient: %s", err))
		utils.Logerror(e)
		return errors.New("Error creating invoice while executing.")
	}
	rowsAffec, _ := res.RowsAffected()
	if err != nil || rowsAffec != 1 {
		e := utils.LogErrorToFile("sql", fmt.Sprintf("Error creating invoice, more than one row afffected: %s", err))
		utils.Logerror(e)
		return errors.New("Server encountered an error while creating invoice.")
	}
	return nil
}



func (dom *Domain) ListPatientInvoice(patient_id string) ([]ent.Invoice,error) {
	rows, err := dom.Dbs.Query(ListPatientInvoicesQuery,patient_id)
	if err != nil {
		e := utils.LogErrorToFile("sql", fmt.Sprintf("Error preparing to List invoice: %s", err))
		utils.Logerror(e)
		return nil, errors.New("Server encountered an error while listing all patient invoices.")
	}
	defer rows.Close()
	var invoices []ent.Invoice
	for rows.Next() {
		var invoice ent.Invoice
		err = rows.Scan(&invoice.InvoiceID, &invoice.PatientID, &invoice.Amount, &invoice.Paid, &invoice.CreatedAt, &invoice.UpdatedAt)
		if err != nil {
			e := utils.LogErrorToFile("sql", fmt.Sprintf("Error scanning for invoices: %s", err))
			utils.Logerror(e)
			return nil, errors.New("Server encountered an error while listing all invoice.")
		}
		invoices = append(invoices, invoice)
	}
	return invoices, nil
}


func (dom *Domain)  MarkAsPaid(invoice_id,status string) error {
	stmt,err := dom.Dbs.Prepare(MarkInvoiceAsPaidQuery)
  if err != nil{
    e := utils.LogErrorToFile("sql",fmt.Sprintf("Error preparing to update invoice: %s",err))
    utils.Logerror(e)
    return errors.New("Server encountered an error while updating invoice status.")
  }
  defer stmt.Close()
  var res sql.Result
  res,err = stmt.Exec(status, invoice_id)
  rowsAffec,_ := res.RowsAffected()
  if err != nil || rowsAffec != 1 {
    e := utils.LogErrorToFile("sql",fmt.Sprintf("Error updating invoice with id: %s. %s",invoice_id,err))
    utils.Logerror(e)
    return errors.New("Server encountered an error while updating invoice as paid.")
  }
  return nil
}


func (dom *Domain) ListInvoices(status string) ([]ent.Invoice,error) {
	rows, err := dom.Dbs.Query(ListInvoicesQuery, status)
	if err != nil {
		e := utils.LogErrorToFile("sql", fmt.Sprintf("Error preparing to List invoice: %s", err))
		utils.Logerror(e)
		return nil, errors.New("Server encountered an error while listing all invoices.")
	}
	defer rows.Close()
	var invoices []ent.Invoice
	for rows.Next() {
		var invoice ent.Invoice
		err = rows.Scan(&invoice.InvoiceID, &invoice.PatientID, &invoice.Amount, &invoice.Paid, &invoice.CreatedAt, &invoice.UpdatedAt)
		if err != nil {
			e := utils.LogErrorToFile("sql", fmt.Sprintf("Error scanning for invoice: %s", err))
			utils.Logerror(e)
			return nil, errors.New("Server encountered an error while listing all invoice.")
		}
		patientData, err := dom.ViewPatient(invoice.PatientID)
		if err != nil {
			utils.Danger(err)
		}
		invoice.PatientData = patientData
		invoices = append(invoices, invoice)
	}
	return invoices, nil
}
