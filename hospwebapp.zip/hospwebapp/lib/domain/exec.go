package domain

/*
	This package holdds the domain queries to be made
*/
//
// import (
// 	"context"
// 	"database/sql"
// 	"errors"
// 	"fmt"
//
// 	"hospwebapp/lib/entities"
// 	"hospwebapp/lib/utils"
// )

const (
	InsertUserQuery = `INSERT INTO users (user_id, username, password_hash, email, role, gender, created_at, updated_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?)`
	UpdateUserQuery = `UPDATE users SET username=?, password_hash=?, email=?, role=?, gender=?, updated_at=? WHERE user_id=?`
	DeleteUserQuery = `DELETE FROM users WHERE user_id=?`
	ListUsersQuery  = `SELECT id, user_id, username, password_hash, email, role, gender, created_at, updated_at FROM users`
	ListUsersByRoleQuery = `SELECT id, user_id, username, password_hash, email, role, gender, created_at, updated_at FROM users WHERE role = ?`
	AuthUserQuery = `SELECT ID, user_id, username, password_hash, email, role, gender, created_at, updated_at FROM users WHERE email = ?;`
	ViewUserQuery = `SELECT id, user_id, username, password_hash, email, role, gender, created_at, updated_at FROM user WHERE userid = ?;`

	InsertPatientQuery = `INSERT INTO patients (uuid, full_name, email, contact_number, date_of_birth, gender, address, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?)`
	UpdatePatientQuery = `UPDATE patients SET full_name=?, email=?, contact_number=?, date_of_birth=?, gender=?, address=? WHERE uuid=?`
	DeletePatientQuery = `DELETE FROM patients WHERE uuid=?`
	ListPatientsQuery  = `SELECT  uuid, full_name, email, contact_number, date_of_birth, gender, address, created_at FROM patients`
	ViewPatientByUUIDQuery = `SELECT uuid, full_name, email, contact_number, date_of_birth, gender, address, created_at FROM patients WHERE uuid = ?`
	ViewPatientByEmailQuery = `SELECT uuid, full_name, email, contact_number, date_of_birth, gender, address, created_at FROM patients WHERE email = ?`
	ListPatientsByGenderQuery = `SELECT uuid, full_name, email, contact_number, date_of_birth, gender, address, created_at FROM patients WHERE gender = ?`

	InsertDoctorTypeQuery = `INSERT INTO doctor_types (name_type, created_at, updated_at) VALUES (?, ?, ?)`
	UpdateDoctorTypeQuery = `UPDATE doctor_types SET updated_at=? WHERE name_type=?`
	DeleteDoctorTypeQuery = `DELETE FROM doctor_types WHERE name_type=?`
	ListDoctorTypesQuery  = `SELECT name_type, created_at, updated_at FROM doctor_types`

	InsertAppointmentQuery = `INSERT INTO appointment (appointment_id, username, email, number, reason, message, appointment_time, status, created_at, updated_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`
	UpdateAppointmentQuery = `UPDATE appointment SET username=?, email=?, number=?, reason=?, message=?, appointment_time=?, status=?, updated_at=? WHERE appointment_id=?`
	UpdateAppointmentTimeQuery = `UPDATE appointment SET appointment_time = ?, updated_at = NOW() WHERE appointment_id = ?`
	UpdateAppointmentAsHandledQuery = `UPDATE appointment SET status = ?, updated_at = NOW() WHERE appointment_id = ?`
	DeleteAppointmentQuery = `DELETE FROM appointment WHERE appointment_id=?`
	ListAppointmentsQuery  = `SELECT appointment_id, username, email, number, reason, message, appointment_time, status, created_at, updated_at FROM appointment WHERE status = ?;`
	ListAppointmentsReasonQuery = `SELECT appointment_id, username, email, number, reason, message, appointment_time, status, created_at, updated_at FROM appointment WHERE reason = ?;`
	ListAppintmentsReasonStatusQuery = `SELECT appointment_id, username, email, number, reason, message, appointment_time, status, created_at, updated_at FROM appointment WHERE (stastus = ? AND  reason = ?);`
	ViewAppointmentQuery = `SELECT appointment_id, username, email, number, reason, message, appointment_time, status, created_at, updated_at FROM appointment WHERE appointment_id = ?;`

	InsertPatientRecordQuery = `INSERT INTO patient_records (record_id, patient_id, record, updated_by, doctor_name, status, created_at, updated_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?)`
	UpdatePatientRecordQuery = `UPDATE patient_records SET record=?, updated_by=?, doctor_name=?, status=?, updated_at=? WHERE record_id=?`
	DeletePatientRecordQuery = `DELETE FROM patient_records WHERE record_id=?`
	ListPatientRecordsQuery  = `SELECT record_id, patient_id, record, updated_by, doctor_name, status, created_at, updated_at FROM patient_records WHERE patient_id = ?`

	InsertInvoiceQuery = `INSERT INTO invoice (invoice_id, patient_id, amount, status, issued_at, updated_at) VALUES (?, ?, ?, ?, ?, ?)`
	//UpdateInvoiceQuery = `UPDATE invoice SET patient_id=?, amount=?, paid=?, updated_at=? WHERE invoice_id=?`
	MarkInvoiceAsPaidQuery = `UPDATE invoice SET status=? WHERE invoice_id=?`
	DeleteInvoiceQuery = `DELETE FROM invoice WHERE invoice_id=?`
	ListInvoicesQuery  = `SELECT  invoice_id, patient_id, amount, status, issued_at, updated_at FROM invoice WHERE status = ?`
	ListPatientInvoicesQuery  = `SELECT id, invoice_id, patient_id, amount, status, issued_at, updated_at FROM invoice WHERE patient_id = ?`

)

/*
func execEntity(ctx context.Context, db *sql.DB, query string, args ...interface{}) error {
	stmt, err := db.PrepareContext(ctx, query)
	if err != nil {
		return utils.LogAndReturnSQLError("Prepare", err)
	}
	defer stmt.Close()
	_, err = stmt.ExecContext(ctx, args...)
	return utils.LogAndReturnSQLError("Exec", err)
}


func (dom *Domain) CreateUser(ctx context.Context, u entities.User) error {
	return execEntity(ctx, dom.Dbs, insertUserQuery, u.UserID, u.Username, u.PasswordHash, u.Email, u.Role, u.Gender, u.CreatedAt, u.UpdatedAt)
}
func (dom *Domain) UpdateUser(ctx context.Context, u entities.User) error {
	return execEntity(ctx, dom.Dbs, updateUserQuery, u.Username, u.PasswordHash, u.Email, u.Role, u.Gender, u.UpdatedAt, u.UserID)
}
func (dom *Domain) DeleteUser(ctx context.Context, userID string) error {
	return execEntity(ctx, dom.Dbs, deleteUserQuery, userID)
}
func (dom *Domain) ListUsers(ctx context.Context) ([]entities.User, error) {
	rows, err := dom.Dbs.QueryContext(ctx, listUsersQuery)
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	var users []entities.User
	for rows.Next() {
		var u entities.User
		err := rows.Scan(&u.ID, &u.UserID, &u.Username, &u.PasswordHash, &u.Email, &u.Role, &u.Gender, &u.CreatedAt, &u.UpdatedAt)
		if err != nil {
			return nil, err
		}
		users = append(users, u)
	}
	return users, nil
}
*/
