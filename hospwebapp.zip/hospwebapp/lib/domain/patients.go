package domain

/* Patient functionalities module */

import (
	"fmt"
	"errors"
	"database/sql"
	"hospwebapp/lib/utils"
	ent "hospwebapp/lib/entities"

	_ "github.com/go-sql-driver/mysql"
)


// Add encryption
func (dom *Domain) CreatePatient(patient ent.Patient) error {
	var ins *sql.Stmt
	ins, err := dom.Dbs.Prepare(InsertPatientQuery)
	if err != nil {
		e := utils.LogErrorToFile("sql", fmt.Sprintf("Error Preparing to create patient: %s", err))
		utils.Logerror(e)
		return errors.New("Server encountered an error while creating patient, Try again later :).")
	}
	defer ins.Close()
	res, err := ins.Exec(patient.UUID, patient.FullName, patient.Email, patient.ContactNumber, patient.DateOfBirth, patient.Gender, patient.Address, patient.CreatedAt, patient.UpdatedAt)
	if err != nil {
		e := utils.LogErrorToFile("sql", fmt.Sprintf("Error executing insert patient: %s", err))
		utils.Logerror(e)
		return errors.New("Error creating patient while executing.")
	}
	rowsAffec, _ := res.RowsAffected()
	if err != nil || rowsAffec != 1 {
		e := utils.LogErrorToFile("sql", fmt.Sprintf("Error creating patient, more than one row afffected: %s", err))
		utils.Logerror(e)
		return errors.New("Server encountered an error while creating patient.")
	}
	return nil
}

func (dom *Domain) ListPatients() ([]ent.Patient, error) {
	rows, err := dom.Dbs.Query(ListPatientsQuery)
	if err != nil {
		e := utils.LogErrorToFile("sql", fmt.Sprintf("Error preparing to List patients: %s", err))
		utils.Logerror(e)
		return nil, errors.New("Server encountered an error while listing all patients.")
	}
	defer rows.Close()
	var patients []ent.Patient
	for rows.Next() {
		var patient ent.Patient
		err = rows.Scan(&patient.UUID, &patient.FullName, &patient.Email, &patient.ContactNumber, &patient.DateOfBirth, &patient.Gender, &patient.Address, &patient.CreatedAt, &patient.UpdatedAt)
		if err != nil {
			e := utils.LogErrorToFile("sql", fmt.Sprintf("Error scanning for patients: %s", err))
			utils.Logerror(e)
			return nil, errors.New("Server encountered an error while listing all patients.")
		}
		patients = append(patients, patient)
	}
	return patients, nil
}

func (dom *Domain) ListPatientsByGender(gender string) ([]ent.Patient, error) {
	rows, err := dom.Dbs.Query(ListPatientsByGenderQuery,gender)
	if err != nil {
		e := utils.LogErrorToFile("sql", fmt.Sprintf("Error preparing to List patients: %s", err))
		utils.Logerror(e)
		return nil, errors.New("Server encountered an error while listing all patients.")
	}
	defer rows.Close()
	var patients []ent.Patient
	for rows.Next() {
		var patient ent.Patient
		err = rows.Scan(&patient.UUID, &patient.FullName, &patient.Email, &patient.ContactNumber, &patient.DateOfBirth, &patient.Gender, &patient.Address, &patient.CreatedAt, &patient.UpdatedAt)
		if err != nil {
			e := utils.LogErrorToFile("sql", fmt.Sprintf("Error scanning for patient: %s", err))
			utils.Logerror(e)
			return nil, errors.New("Server encountered an error while listing all patients.")
		}
		patients = append(patients, patient)
	}
	return patients, nil
}

func (dom *Domain) ViewPatient(uid string) (*ent.Patient, error) {
	var patient ent.Patient
	row := dom.Dbs.QueryRow(ViewPatientByUUIDQuery, uid)
	err := row.Scan(&patient.UUID, &patient.FullName, &patient.Email, &patient.ContactNumber, &patient.DateOfBirth, &patient.Gender, &patient.Address, &patient.CreatedAt, &patient.UpdatedAt)
	if err != nil {
		e := utils.LogErrorToFile("sql", fmt.Sprintf("Error viewing patient with id %s %s", uid, err))
		utils.Logerror(e)
		return nil, errors.New(fmt.Sprintf("Server encountered an error while viewing patient  with id of %s", uid))
	}
	return &patient, nil
}
