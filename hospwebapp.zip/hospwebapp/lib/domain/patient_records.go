package domain

/* Patient Records functionalities module */

import (
	"fmt"
	"errors"
	"database/sql"
	"hospwebapp/lib/utils"
	ent "hospwebapp/lib/entities"

	_ "github.com/go-sql-driver/mysql"
)


func (dom *Domain) CreatePatientRecord(pr ent.PatientRecord) error {
	var ins *sql.Stmt
	ins, err := dom.Dbs.Prepare(InsertPatientRecordQuery)
	if err != nil {
		e := utils.LogErrorToFile("sql", fmt.Sprintf("Error Preparing to create patient record: %s", err))
		utils.Logerror(e)
		return errors.New("Server encountered an error while creating patient record, Try again later :).")
	}
	defer ins.Close()
	res, err := ins.Exec(pr.RecordID, pr.PatientID, pr.Record, pr.UpdatedBy, pr.DoctorName, pr.Status, pr.CreatedAt, pr.UpdatedAt)
	if err != nil {
		e := utils.LogErrorToFile("sql", fmt.Sprintf("Error executing insert patient record: %s", err))
		utils.Logerror(e)
		return errors.New("Error creating patient record while executing.")
	}
	rowsAffec, _ := res.RowsAffected()
	if err != nil || rowsAffec != 1 {
		e := utils.LogErrorToFile("sql", fmt.Sprintf("Error creating patient record, more than one row afffected: %s", err))
		utils.Logerror(e)
		return errors.New("Server encountered an error while creating patient record.")
	}
	return nil
}



func (dom *Domain) ListPatientRecords(patient_id string) ([]ent.PatientRecord,error) {
	rows, err := dom.Dbs.Query(ListPatientRecordsQuery,patient_id)
	if err != nil {
		e := utils.LogErrorToFile("sql", fmt.Sprintf("Error preparing to List patient records: %s", err))
		utils.Logerror(e)
		return nil, errors.New("Server encountered an error while listing all patient invoices.")
	}
	defer rows.Close()
	var prs []ent.PatientRecord
	for rows.Next() {
		var pr ent.PatientRecord
		err = rows.Scan(&pr.RecordID, &pr.PatientID, &pr.Record, &pr.UpdatedBy, &pr.DoctorName, &pr.Status, &pr.CreatedAt, &pr.UpdatedAt)
		if err != nil {
			e := utils.LogErrorToFile("sql", fmt.Sprintf("Error scanning for patient records: %s", err))
			utils.Logerror(e)
			return nil, errors.New("Server encountered an error while listing all patient records.")
		}
		prs = append(prs, pr)
	}
	return prs, nil
}


func (dom *Domain)  UpdateRecordStatus(pr ent.PatientRecord) error {
	stmt,err := dom.Dbs.Prepare(UpdatePatientRecordQuery)
  if err != nil{
    e := utils.LogErrorToFile("sql",fmt.Sprintf("Error preparing to update record status: %s",err))
    utils.Logerror(e)
    return errors.New("Server encountered an error while updating record status.")
  }
  defer stmt.Close()
  var res sql.Result
  res,err = stmt.Exec(&pr.Record, &pr.UpdatedBy, &pr.DoctorName, &pr.Status, &pr.UpdatedAt, &pr.RecordID)
  rowsAffec,_ := res.RowsAffected()
  if err != nil || rowsAffec != 1 {
    e := utils.LogErrorToFile("sql",fmt.Sprintf("Error updating record with id: %s. %s",pr.RecordID,err))
    utils.Logerror(e)
    return errors.New("Server encountered an error while updating invoice as paid.")
  }
  return nil
}
