package domain

import (
	"fmt"
	"errors"
	"database/sql"
	"hospwebapp/lib/utils"
	ent "hospwebapp/lib/entities"

	_ "github.com/go-sql-driver/mysql"
	"golang.org/x/crypto/bcrypt"
)


// Add encryption
func (dom *Domain) CreateUser(u ent.User) error {
	var passwordHash []byte
	//create their hashes
	passwordHash, err := bcrypt.GenerateFromPassword([]byte(u.Password), bcrypt.DefaultCost)
	if err != nil {
		e := utils.LogErrorToFile("sql", fmt.Sprintf("Error creating password hash: %s", err))
		utils.Logerror(e)
		return err
	}
	var ins *sql.Stmt
	ins, err = dom.Dbs.Prepare(InsertUserQuery)
	if err != nil {
		e := utils.LogErrorToFile("sql", fmt.Sprintf("Error Preparing to create user: %s", err))
		utils.Logerror(e)
		return errors.New("Server encountered an error while creating user, Try again later :).")
	}
	defer ins.Close()
	res, err := ins.Exec(u.UserID, u.Username, passwordHash, u.Email, u.Role, u.Gender, u.CreatedAt, u.UpdatedAt)
	if err != nil {
		e := utils.LogErrorToFile("sql", fmt.Sprintf("Error executing insert user: %s", err))
		utils.Logerror(e)
		return errors.New("Error creating user while executing.")
	}
	rowsAffec, _ := res.RowsAffected()
	if err != nil || rowsAffec != 1 {
		e := utils.LogErrorToFile("sql", fmt.Sprintf("Error creating user, more than one row afffected: %s", err))
		utils.Logerror(e)
		return errors.New("Server encountered an error while creating user.")
	}
	return nil
}

func (dom *Domain) ListUsers() ([]ent.User, error) {
	rows, err := dom.Dbs.Query(ListUsersQuery)
	if err != nil {
		e := utils.LogErrorToFile("sql", fmt.Sprintf("Error preparing to List users: %s", err))
		utils.Logerror(e)
		return nil, errors.New("Server encountered an error while listing all users.")
	}
	defer rows.Close()
	var users []ent.User
	for rows.Next() {
		var u ent.User
		err = rows.Scan(&u.UserID, &u.Username, &u.Password, &u.Email, &u.Role, &u.Gender, &u.CreatedAt, &u.UpdatedAt)
		if err != nil {
			e := utils.LogErrorToFile("sql", fmt.Sprintf("Error scanning for user: %s", err))
			utils.Logerror(e)
			return nil, errors.New("Server encountered an error while listing all users.")
		}
		users = append(users, u)
	}
	return users, nil
}

func (dom *Domain) ListUsersByRole(role string) ([]ent.User, error) {
	rows, err := dom.Dbs.Query(ListUsersByRoleQuery,role)
	if err != nil {
		e := utils.LogErrorToFile("sql", fmt.Sprintf("Error preparing to List users: %s", err))
		utils.Logerror(e)
		return nil, errors.New("Server encountered an error while listing all users.")
	}
	defer rows.Close()
	var users []ent.User
	for rows.Next() {
		var u ent.User
		err = rows.Scan(&u.UserID, &u.Username, &u.Password, &u.Email, &u.Role, &u.Gender, &u.CreatedAt, &u.UpdatedAt)
		if err != nil {
			e := utils.LogErrorToFile("sql", fmt.Sprintf("Error scanning for user: %s", err))
			utils.Logerror(e)
			return nil, errors.New("Server encountered an error while listing all users.")
		}
		u.Password = ""
		users = append(users, u)
	}
	return users, nil
}

func (dom *Domain) ViewUser(uid string) (*ent.User, error) {
	var u ent.User
	row := dom.Dbs.QueryRow(ViewUserQuery, uid)
	err := row.Scan(&u.ID, &u.UserID, &u.Username, &u.Password, &u.Email, &u.Role, &u.Gender, &u.CreatedAt, &u.UpdatedAt)
	if err != nil {
		e := utils.LogErrorToFile("sql", fmt.Sprintf("Error viewing user with id %s %s", uid, err))
		utils.Logerror(e)
		return nil, errors.New(fmt.Sprintf("Server encountered an error while viewing user with id of %s", uid))
	}
	return &u, nil
}

// Authenticates to the System
func (dom *Domain) Authenticate(email, password string) (*ent.User, bool) {
	var u ent.User
	row := dom.Dbs.QueryRow(AuthUserQuery, email)
	fmt.Println("DB mail: ", email)
	err := row.Scan(&u.ID, &u.UserID, &u.Username, &u.Password, &u.Email, &u.Role, &u.Gender, &u.CreatedAt, &u.UpdatedAt)
	if err != nil {
		e := utils.LogErrorToFile("sql", fmt.Sprintf("Error scanning rows for authentication %s", err))
		utils.Logerror(e)
		return &u, false
	}
	err = bcrypt.CompareHashAndPassword([]byte(u.Password), []byte(password))
	if err != nil {
		e := utils.LogErrorToFile("auth", fmt.Sprintf("Wrong login attempt for email %s with password %s  %s", email, password, err))
		utils.Logerror(e)
		return &u, false
	}
	u.Password = ""
	return &u, true
}
