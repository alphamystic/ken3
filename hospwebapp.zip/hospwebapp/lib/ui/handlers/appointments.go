package handlers

/*
  Handler for all apointment functionalities.
*/
import(
  "fmt"
  "time"
  "net/http"
  "encoding/json"
  "hospwebapp/lib/utils"
  dom"hospwebapp/lib/domain"
  ent"hospwebapp/lib/entities"
)

func (hnd *Handler) Listappointments(res http.ResponseWriter, req *http.Request) {
  _, err := hnd.GetUDFromToken(req)
	if err != nil {
		utils.Warning(fmt.Sprintf("%s", err))
		http.Redirect(res, req, "/logout", http.StatusSeeOther)
		return
	}
  tpl,err := hnd.GetATemplateLIN("lapp","listappointments.tmpl")
  if err != nil{
    utils.Warning(fmt.Sprintf("%s",err))
    http.Error(res, "An error occurred", http.StatusInternalServerError)
  }
  dmn := &dom.Domain{Dbs: hnd.Dbs}
  appointments,err := dmn.ListAppointmentsByStatus("Pending")
  if err != nil {
    http.Redirect(res, req, "/internalServerError", http.StatusSeeOther)
    return
  }
  tpl.ExecuteTemplate(res,"lapp",HOME{
    "appointments": appointments,
  })
}

func (hnd *Handler) ListTodaysAppointments(res http.ResponseWriter, req *http.Request) {
  _, err := hnd.GetUDFromToken(req)
	if err != nil {
		utils.Warning(fmt.Sprintf("%s", err))
		http.Redirect(res, req, "/logout", http.StatusSeeOther)
		return
	}
  tpl,err := hnd.GetATemplateLIN("lapp","listappointments.tmpl")
  if err != nil{
    utils.Warning(fmt.Sprintf("%s",err))
    http.Error(res, "An error occurred", http.StatusInternalServerError)
  }
  dmn := &dom.Domain{Dbs: hnd.Dbs}
  appointments,err := dmn.ListAppointmentsByStatus("Pending")
  if err != nil {
    http.Redirect(res, req, "/internalServerError", http.StatusSeeOther)
    return
  }
  tpl.ExecuteTemplate(res,"lapp",HOME{
    "appointments": appointments,
  })
}

func (hnd *Handler) Listpatients(res http.ResponseWriter, req *http.Request) {
  tpl,err := hnd.GetATemplateLIN("lp","listpatients.tmpl")
  if err != nil{
    utils.Warning(fmt.Sprintf("%s",err))
    http.Error(res, "An error occurred", http.StatusInternalServerError)
  }
  tpl.ExecuteTemplate(res,"lp",nil)
  // _, err := hnd.GetUDFromToken(req)
	// if err != nil {
	// 	utils.Warning(fmt.Sprintf("%s", err))
	// 	http.Redirect(res, req, "/logout", http.StatusSeeOther)
	// 	return
	// }
  // tpl,err := hnd.GetATemplateLIN("lp","listpatients.tmpl")
  // if err != nil{
  //   utils.Warning(fmt.Sprintf("%s",err))
  //   http.Error(res, "An error occurred", http.StatusInternalServerError)
  // }
  // dmn := &dom.Domain{Dbs: hnd.Dbs}
  // appointments,err := dmn.ListAppointmentsByStatus("lp")
  // if err != nil {
  //   http.Redirect(res, req, "/internalServerError", http.StatusSeeOther)
  //   return
  // }
  // tpl.ExecuteTemplate(res,"lapp",HOME{
  //   "appointments": appointments,
  // })
}


func (hnd *Handler) Scheduleappointment(res http.ResponseWriter, req *http.Request) {
	if req.Method != http.MethodPost {
		http.Error(res, "Invalid request method", http.StatusMethodNotAllowed)
		return
	}

	var temp struct {
		Name            string `json:"name"`
		Email           string `json:"email"`
		Number          string `json:"number"`
		Reason          string `json:"reason"`
		Message         string `json:"message"`
		AppointmentTime string `json:"appointment_time"`
	}

	// Decode request body into temp struct
	if err := json.NewDecoder(req.Body).Decode(&temp); err != nil {
		http.Error(res, "Invalid JSON data", http.StatusBadRequest)
		return
	}

	// Parse string to time.Time
	apptTime, err := time.Parse("2006-01-02T15:04", temp.AppointmentTime)
	if err != nil {
		http.Error(res, "Invalid appointment_time format", http.StatusBadRequest)
		fmt.Println("Time parse error:", err)
		return
	}

	// Fill in the Appointment struct
	appt := ent.Appointment{
		AppointmentID:   utils.GenerateUUID(),
		Name:            temp.Name,
		Email:           temp.Email,
		Number:          temp.Number,
		Reason:          temp.Reason,
		Message:         temp.Message,
		AppointmentTime: apptTime.Format("2006-01-02 15:04:05"), // Optional if DB expects string
		Status:          "Pending",
	}
	appt.Touch()

	// Insert into DB
	dmn := &dom.Domain{Dbs: hnd.Dbs}
	if err := dmn.CreateAppointment(appt); err != nil {
		res.WriteHeader(http.StatusInternalServerError)
		json.NewEncoder(res).Encode(map[string]string{
			"status":  "error",
			"message": "Failed to create appointment.",
		})
		return
	}

	res.WriteHeader(http.StatusOK)
	json.NewEncoder(res).Encode(map[string]string{
		"status":  "success",
		"message": "Appointment scheduled successfully!",
	})
}

func (hnd *Handler) RescheduleAppointment(res http.ResponseWriter, req *http.Request) {
	if req.Method != http.MethodPost {
		http.Error(res, "Method not allowed", http.StatusMethodNotAllowed)
		return
	}

	var payload struct {
		AppointmentUUID string `json:"appointment_uuid"`
		NewDatetime     string `json:"new_datetime"`
	}

	if err := json.NewDecoder(req.Body).Decode(&payload); err != nil {
		http.Error(res, "Invalid JSON payload", http.StatusBadRequest)
		return
	}

	if payload.AppointmentUUID == "" || payload.NewDatetime == "" {
		http.Error(res, "Missing appointment UUID or new date/time", http.StatusBadRequest)
		return
	}

	newTime, err := time.Parse(time.RFC3339, payload.NewDatetime)
	if err != nil {
		http.Error(res, "Invalid datetime format. Use RFC3339 format.", http.StatusBadRequest)
		return
	}

	dmn := &dom.Domain{Dbs: hnd.Dbs}
	err = dmn.RescheduleAppointment(payload.AppointmentUUID, newTime.String())
	if err != nil {
		http.Error(res, "Failed to reschedule appointment: "+err.Error(), http.StatusInternalServerError)
		return
	}

	res.WriteHeader(http.StatusOK)
	json.NewEncoder(res).Encode(map[string]string{
		"status":  "success",
		"message": "Appointment rescheduled successfully",
	})
}
