package handlers

import(
  "fmt"
  "net/http"
  "hospwebapp/lib/utils"
)


func (hnd *Handler) Dash(res http.ResponseWriter, req *http.Request) {
  ud, err := hnd.GetUDFromToken(req)
	if err != nil {
    fmt.Println(err)
    utils.Warning("None admin tryig to access dashboard..... The request can be logged into a reddis server.")
		http.Redirect(res, req, "/logout", http.StatusSeeOther)
		return
	}
  switch ud.Role {
  case "Doctor":
    tpl,err := hnd.GetATemplateLIN("dla","invoice.tmpl")
    if err != nil{
      utils.Warning(fmt.Sprintf("%s",err))
      http.Error(res, "An error occurred", http.StatusInternalServerError)
    }
    tpl.ExecuteTemplate(res,"dla",nil)
    return
  case "Receptionist":
    tpl,err := hnd.GetATemplateLIN("nfh","listappointments.tmpl")
    if err != nil{
      utils.Warning(fmt.Sprintf("%s",err))
      http.Error(res, "An error occurred", http.StatusInternalServerError)
    }
    tpl.ExecuteTemplate(res,"nfh",nil)
  // case "Manager":
  //   tpl,err := hnd.GetATemplateLIN("nfh","listappointments.tmpl")
  //   if err != nil{
  //     utils.Warning(fmt.Sprintf("%s",err))
  //     http.Error(res, "An error occurred", http.StatusInternalServerError)
  //   }
  //   tpl.ExecuteTemplate(res,"nfh",nil)
  // case "Billing":
  //   tpl,err := hnd.GetATemplateLIN("nfh","listappointments.tmpl")
  //   if err != nil{
  //     utils.Warning(fmt.Sprintf("%s",err))
  //     http.Error(res, "An error occurred", http.StatusInternalServerError)
  //   }
  //   tpl.ExecuteTemplate(res,"nfh",nil)
  case "Admin":
    tpl,err := hnd.GetATemplateLIN("nfh","listappointments.tmpl")
    if err != nil{
      utils.Warning(fmt.Sprintf("%s",err))
      http.Error(res, "An error occurred", http.StatusInternalServerError)
    }
    tpl.ExecuteTemplate(res,"nfh",nil)
  default:
    http.Redirect(res,req, "/logout",http.StatusSeeOther)
    return
  }
}


func (hnd *Handler) P404(res http.ResponseWriter, req *http.Request) {
  tpl,err := hnd.GetATemplate("nfh","404.tmpl")
  if err != nil{
    utils.Warning(fmt.Sprintf("%s",err))
    http.Error(res, "An error occurred", http.StatusInternalServerError)
  }
  tpl.ExecuteTemplate(res,"nfh",nil)
}


func (hnd *Handler) Home(res http.ResponseWriter, req *http.Request) {
  _, err := hnd.GetUDFromToken(req)
	if err != nil {
    tpl,err := hnd.GetATemplate("home","index.tmpl")
    if err != nil{
      utils.Warning(fmt.Sprintf("%s",err))
      http.Error(res, "An error occurred", http.StatusInternalServerError)
    }
    tpl.ExecuteTemplate(res,"home",nil)
    return
	}
  tpl,err := hnd.GetATemplateLIN("home","index.tmpl")
  if err != nil{
    utils.Warning(fmt.Sprintf("%s",err))
    http.Error(res, "An error occurred", http.StatusInternalServerError)
  }
  tpl.ExecuteTemplate(res,"home",nil)
  return
}

func (hnd *Handler) Internalserverror(res http.ResponseWriter, req *http.Request) {
  tpl,err := hnd.GetATemplateLIN("err500","500.tmpl")
  if err != nil{
    utils.Warning(fmt.Sprintf("%s",err))
    http.Error(res, "An error occurred", http.StatusInternalServerError)
  }
  tpl.ExecuteTemplate(res,"err500",nil)
  return
}
