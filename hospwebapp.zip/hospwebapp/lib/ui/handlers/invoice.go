package handlers

/*
  Handler for all apointment functionalities.
*/
import(
  "fmt"
  //"time"
  "net/http"
  //"encoding/json"
  "hospwebapp/lib/utils"
  dom"hospwebapp/lib/domain"
  //ent"hospwebapp/lib/entities"
)

func (hnd *Handler) Listinvoices(res http.ResponseWriter, req *http.Request) {
  _, err := hnd.GetUDFromToken(req)
	if err != nil {
		utils.Warning(fmt.Sprintf("%s", err))
		http.Redirect(res, req, "/logout", http.StatusSeeOther)
		return
	}
  tpl,err := hnd.GetATemplateLIN("invoice","invoice.tmpl")
  if err != nil{
    utils.Warning(fmt.Sprintf("%s",err))
    http.Error(res, "An error occurred", http.StatusInternalServerError)
  }
  dmn := &dom.Domain{Dbs: hnd.Dbs}
  appointments,err := dmn.ListAppointmentsByStatus("Pending")
  if err != nil {
    http.Redirect(res, req, "/invoice", http.StatusSeeOther)
    return
  }
  tpl.ExecuteTemplate(res,"lapp",HOME{
    "appointments": appointments,
  })
}
