package handlers

/*
  Handler for all apointment functionalities.
*/
import(
  "fmt"
  //"time"
  "net/http"
  "encoding/json"
  "hospwebapp/lib/utils"
  dom"hospwebapp/lib/domain"
  ent"hospwebapp/lib/entities"
)

func (hnd *Handler) Markinvoiceashandled(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodPatch {
		http.Error(w, "Method Not Allowed", http.StatusMethodNotAllowed)
		return
	}

	ud, err := hnd.GetUDFromToken(r)
	if err != nil {
		utils.Warning(fmt.Sprintf("Token error: %s", err))
		http.Redirect(w, r, "/logout", http.StatusSeeOther)
		return
	}

	// Optional: Restrict access
	if ud.Role != "Receptionist"  {
		hnd.RespondJSON(w, "error", "Unauthorized: Only receptionists or accountants can mark invoices as paid.")
		return
	}

	// Extract invoice ID from query
	invoiceID := r.URL.Query().Get("invoiceid")
	if invoiceID == "" {
		hnd.RespondJSON(w, "error", "Missing invoice ID.")
		return
	}

	dmn := &dom.Domain{Dbs: hnd.Dbs}
	err = dmn.MarkAsPaid(invoiceID,"Paid")
	if err != nil {
		hnd.RespondJSON(w, "error", "We are experiencing internal server issues, try again later.")
		return
	}

	hnd.RespondJSON(w, "success", "Invoice marked as paid.")
}



func (h *Handler) Createinvoice(w http.ResponseWriter, r *http.Request) {
	var payload struct {
		Email  string  `json:"patientEmail"`
		Amount float64 `json:"amount"`
	}

	err := json.NewDecoder(r.Body).Decode(&payload)
	if err != nil {
		utils.Logerror(err)
		http.Error(w, "Invalid input", http.StatusBadRequest)
		return
	}

	invoice := ent.Invoice{
		InvoiceID: "INV " + utils.GenerateUUID(),
		Amount:    payload.Amount,
		Paid:      "Pending",
	}
	invoice.Touch()

	dmn := &dom.Domain{Dbs: h.Dbs}
	patient, err := dmn.ViewPatientByEmail(payload.Email)
	if err != nil {
		utils.Logerror(err)
		w.WriteHeader(http.StatusInternalServerError)
		json.NewEncoder(w).Encode(map[string]string{"error": "Failed to find patient"})
		return
	}

	invoice.PatientID = patient.UUID
	err = dmn.CreateInvoice(invoice)
	if err != nil {
		utils.Logerror(err)
		http.Error(w, "Error creating invoice", http.StatusInternalServerError)
		return
	}

	w.Header().Set("Content-Type", "application/json")
	w.WriteHeader(http.StatusCreated)
	json.NewEncoder(w).Encode(map[string]string{"message": "Invoice created successfully!"})
}



func (hnd *Handler) Listinvoices(res http.ResponseWriter, req *http.Request) {
  ud, err := hnd.GetUDFromToken(req)
	if err != nil {
		utils.Warning(fmt.Sprintf("%s", err))
		http.Redirect(res, req, "/logout", http.StatusSeeOther)
		return
	}
  if ud.Role == "Doctor" {
    tpl,err := hnd.GetATemplateDoctor("invoice","invoice.tmpl")
    if err != nil{
      utils.Warning(fmt.Sprintf("%s",err))
      http.Error(res, "An error occurred", http.StatusInternalServerError)
    }
    dmn := &dom.Domain{Dbs: hnd.Dbs}
    pendingInvoices,err := dmn.ListInvoices("Pending")
    if err != nil {
      utils.Logerror(err)
      http.Redirect(res, req, "/internalServerError", http.StatusSeeOther)
      return
    }
    paidInvices,err := dmn.ListInvoices("Paid")
    if err != nil {
      utils.Logerror(err)
      http.Redirect(res, req, "/internalServerError", http.StatusSeeOther)
      return
    }
    tpl.ExecuteTemplate(res,"invoice",HOME{
      "pendingInvoices": pendingInvoices,
      "paidInvoices": paidInvices,
    })
  } else {
    tpl,err := hnd.GetATemplateReception("invoice","invoice.tmpl")
    if err != nil{
      utils.Warning(fmt.Sprintf("%s",err))
      http.Error(res, "An error occurred", http.StatusInternalServerError)
    }
    dmn := &dom.Domain{Dbs: hnd.Dbs}
    pendingInvoices,err := dmn.ListInvoices("Pending")
    if err != nil {
      utils.Logerror(err)
      http.Redirect(res, req, "/internalServerError", http.StatusSeeOther)
      return
    }
    paidInvices,err := dmn.ListInvoices("Paid")
    if err != nil {
      utils.Logerror(err)
      http.Redirect(res, req, "/internalServerError", http.StatusSeeOther)
      return
    }
    tpl.ExecuteTemplate(res,"invoice",HOME{
      "pendingInvoices": pendingInvoices,
      "paidInvoices": paidInvices,
    })
  }
  return
}
