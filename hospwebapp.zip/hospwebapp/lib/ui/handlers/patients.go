package handlers

/*
  Handler for all patient functionalities.
*/
import(
  //"fmt"
  "time"
  "net/http"
  "encoding/json"
  "hospwebapp/lib/utils"
  dom"hospwebapp/lib/domain"
  ent"hospwebapp/lib/entities"
)


func (hnd *Handler) AddPatient(res http.ResponseWriter, req *http.Request) {
	if req.Method != http.MethodPost {
		http.Error(res, "Invalid request method", http.StatusMethodNotAllowed)
		return
	}

	var temp struct {
		FullName    string `json:"fullname"`
		Email       string `json:"email"`
		Number      string `json:"number"`
		Gender      string `json:"gender"`
		Address     string `json:"address"`
		DateOfBirth string `json:"dateofbirth"`
	}

	if err := json.NewDecoder(req.Body).Decode(&temp); err != nil {
		http.Error(res, "Invalid JSON data", http.StatusBadRequest)
		return
	}

	dob, err := time.Parse("2006-01-02", temp.DateOfBirth)
	if err != nil {
		http.Error(res, "Invalid date format", http.StatusBadRequest)
		return
	}

	patient := ent.Patient{
		UUID:          utils.GenerateUUID(),
		FullName:      temp.FullName,
		Email:         temp.Email,
		ContactNumber: temp.Number,
		Gender:        temp.Gender,
		Address:       temp.Address,
		DateOfBirth:   dob,
	}
	patient.Touch()

	dmn := &dom.Domain{Dbs: hnd.Dbs}
	if err := dmn.CreatePatient(patient); err != nil {
		res.WriteHeader(http.StatusInternalServerError)
		json.NewEncoder(res).Encode(map[string]string{
			"status":  "error",
			"message": "Failed to create patient.",
		})
		return
	}

	res.WriteHeader(http.StatusOK)
	json.NewEncoder(res).Encode(map[string]string{
		"status":  "success",
		"message": "Patient added successfully!",
	})
}
