package handlers

/*
  Handler for all patient functionalities.
*/
import(
  "fmt"
  "time"
  "net/http"
  "strings"
  "encoding/json"
  "hospwebapp/lib/utils"
  dom"hospwebapp/lib/domain"
  ent"hospwebapp/lib/entities"
)

func (hnd *Handler) Patient(res http.ResponseWriter, req *http.Request) {
  tpl,err := hnd.GetATemplatePatient("patient","listappointments.tmpl")
  if err != nil{
    utils.Warning(fmt.Sprintf("%s",err))
    http.Error(res, "An error occurred", http.StatusInternalServerError)
  }
  dmn := &dom.Domain{Dbs: hnd.Dbs}
  appointments,err := dmn.ListAppointmentsByStatus("Pending")
  if err != nil {
    http.Redirect(res, req, "/internalServerError", http.StatusSeeOther)
    return
  }
  tpl.ExecuteTemplate(res,"patient",HOME{
    "appointments": appointments,
  })
}


func (hnd *Handler) AddPatient(res http.ResponseWriter, req *http.Request) {
	if req.Method != http.MethodPost {
		http.Error(res, "Invalid request method", http.StatusMethodNotAllowed)
		return
	}

	var temp struct {
		FullName    string `json:"fullname"`
		Email       string `json:"email"`
		Number      string `json:"number"`
		Gender      string `json:"gender"`
		Address     string `json:"address"`
		DateOfBirth string `json:"dateofbirth"`
	}

	if err := json.NewDecoder(req.Body).Decode(&temp); err != nil {
		http.Error(res, "Invalid JSON data", http.StatusBadRequest)
		return
	}

	dob, err := time.Parse("2006-01-02", temp.DateOfBirth)
	if err != nil {
		http.Error(res, "Invalid date format", http.StatusBadRequest)
		return
	}

	patient := ent.Patient{
		UUID:          utils.GenerateUUID(),
		FullName:      temp.FullName,
		Email:         temp.Email,
		ContactNumber: temp.Number,
		Gender:        temp.Gender,
		Address:       temp.Address,
		DateOfBirth:   dob,
	}
	patient.Touch()

	dmn := &dom.Domain{Dbs: hnd.Dbs}
	if err := dmn.CreatePatient(patient); err != nil {
		res.WriteHeader(http.StatusInternalServerError)
		json.NewEncoder(res).Encode(map[string]string{
			"status":  "error",
			"message": "Failed to create patient.",
		})
		return
	}

	res.WriteHeader(http.StatusOK)
	json.NewEncoder(res).Encode(map[string]string{
		"status":  "success",
		"message": "Patient added successfully!",
	})
}

func (hnd *Handler) Listpatients(res http.ResponseWriter, req *http.Request) {
  ud, err := hnd.GetUDFromToken(req)
	if err != nil {
		utils.Warning(fmt.Sprintf("%s", err))
		http.Redirect(res, req, "/logout", http.StatusSeeOther)
		return
	}
  dmn := &dom.Domain{Dbs: hnd.Dbs}
  patients,err := dmn.ListPatients()
  if err != nil {
    utils.Logerror(err)
    http.Redirect(res, req, "/internalServerError", http.StatusSeeOther)
    return
  }
  if ud.Role == "Doctor"{
    tpl,err := hnd.GetATemplateDoctor("lp","listpatients.tmpl")
    if err != nil{
      utils.Warning(fmt.Sprintf("%s",err))
      http.Error(res, "An error occurred", http.StatusInternalServerError)
    }
    tpl.ExecuteTemplate(res,"lp",HOME{
      "patients": patients,
    })
  } else {
    tpl,err := hnd.GetATemplateReception("lp","listpatients.tmpl")
    if err != nil{
      utils.Warning(fmt.Sprintf("%s",err))
      http.Error(res, "An error occurred", http.StatusInternalServerError)
    }
    tpl.ExecuteTemplate(res,"lp",HOME{
      "patients": patients,
    })
  }
  return
}


func (hnd *Handler) Viewpatient(res http.ResponseWriter, req *http.Request) {
  ud, err := hnd.GetUDFromToken(req)
	if err != nil {
		utils.Warning(fmt.Sprintf("%s", err))
		http.Redirect(res, req, "/logout", http.StatusSeeOther)
		return
	}
  parts := strings.Split(req.URL.Path, "/")
  if len(parts) < 3 {
  	http.Error(res, "Invalid URL format", http.StatusBadRequest)
  	return
  }

  rawParam := parts[2] // "patientid=6d09201e-efa0-4272-be89-cf5657f29dba"
  kv := strings.SplitN(rawParam, "=", 2)
  if len(kv) != 2 {
  	http.Error(res, "Invalid patient ID format", http.StatusBadRequest)
  	return
  }
  patientid := kv[1]

  dmn := &dom.Domain{Dbs: hnd.Dbs}
  patientData,err := dmn.ViewPatient(patientid)
  if err != nil {
    utils.Logerror(err)
    http.Redirect(res, req, "/internalServerError", http.StatusSeeOther)
    return
  }
  patientsRecords,err := dmn.ListPatientRecords(patientid)
  if err != nil {
    utils.Logerror(err)
    http.Redirect(res, req, "/internalServerError", http.StatusSeeOther)
    return
  }
  if ud.Role == "Doctor"{
    tpl,err := hnd.GetATemplateDoctor("lpr","listpatientrecords.tmpl")
    if err != nil{
      utils.Warning(fmt.Sprintf("%s",err))
      http.Error(res, "An error occurred", http.StatusInternalServerError)
    }
    err = tpl.ExecuteTemplate(res,"lpr",HOME{
      "patientData": patientData,
      "patientsRecords": patientsRecords,
    })
    if err !=  nil {
      fmt.Println(err)
      http.Redirect(res,req, "/internalServerError", http.StatusSeeOther)
      return
    }
  } else {
    tpl,err := hnd.GetATemplateReception("lpr","listpatientrecords.tmpl")
    if err != nil{
      utils.Warning(fmt.Sprintf("%s",err))
      http.Error(res, "An error occurred", http.StatusInternalServerError)
    }
    tpl.ExecuteTemplate(res,"lpr",HOME{
      "patientData": patientData,
      "patientsRecords": patientsRecords,
    })
  }
  return
}


func (hnd *Handler) SavePatientRecordHandler(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodPost {
		http.Error(w, "Method Not Allowed", http.StatusMethodNotAllowed)
		return
	}
  ud, err := hnd.GetUDFromToken(r)
	if err != nil {
		utils.Warning(fmt.Sprintf("%s", err))
		http.Redirect(w, r, "/logout", http.StatusSeeOther)
		return
	}
  if ud.Role != "Doctor"{
    hnd.RespondJSON(w, "error", "Only Doctors can update or add a patient record.")
		return
  }

	var payload struct {
		RecordID   string `json:"record_id"`
		PatientID  string `json:"patient_id"`
		Record     string `json:"record"`
		UpdatedBy  string `json:"updated_by"`
		DoctorName string `json:"doctor_name"`
		Status     string `json:"status"`
	}

	if err := json.NewDecoder(r.Body).Decode(&payload); err != nil {
		hnd.RespondJSON(w, "error", "Invalid request payload")
		return
	}

	pr := ent.PatientRecord{
		RecordID:   payload.RecordID,
		PatientID:  payload.PatientID,
		Record:     payload.Record,
		UpdatedBy:  payload.UpdatedBy,
		DoctorName: payload.DoctorName,
		Status:     payload.Status,
	}
  pr.Touch()
  if pr.DoctorName == "" || pr.UpdatedBy == "" {
      pr.DoctorName = ud.Username
      pr.UpdatedBy = ud.UserID
  }
  pr.UpdatedBy = ud.UserID

  dmn := &dom.Domain{Dbs: hnd.Dbs}
	if payload.RecordID == "" {
		// Create New
		pr.RecordID = utils.GenerateUUID()
		err = dmn.CreatePatientRecord(pr)
	} else {
		// Update Existing
		err = dmn.UpdateRecordStatus(pr)
	}

	if err != nil {
		hnd.RespondJSON(w, "error", err.Error())
		return
	}
	hnd.RespondJSON(w, "success", "Patient record saved successfully.")
}

func (hnd *Handler) RespondJSON(w http.ResponseWriter, status string, message string) {
	w.Header().Set("Content-Type", "application/json")
	json.NewEncoder(w).Encode(map[string]string{
		"status":  status,
		"message": message,
	})
}
