from docx import Document
from docx.shared import Inches

# Create a new Word Document
doc = Document()
doc.add_heading('MedPro Hospital Appointment Booking System - Data Dictionary', 0)

# Define tables and fields
tables = {
    "users": [
        ("Field", "Data Type", "Description"),
        ("id", "INT (AUTO_INCREMENT, PK)", "Unique internal ID for the user"),
        ("user_id", "VARCHAR(255), NOT NULL", "External/public user identifier"),
        ("username", "VARCHAR(50), NOT NULL", "Name used to login"),
        ("password_hash", "VARCHAR(255), NOT NULL", "Encrypted user password"),
        ("email", "VARCHAR(100), UNIQUE, NULLABLE", "User's email address"),
        ("role", "ENUM('Doctor','Receptionist','Admin','Manager','Billing')", "User's system role"),
        ("gender", "ENUM('Male','Female','Other')", "Gender identity"),
        ("created_at", "TIMESTAMP, DEFAULT CURRENT_TIMESTAMP", "Record creation timestamp"),
        ("updated_at", "TIMESTAMP, NULLABLE", "Record last updated timestamp"),
    ],
    "patients": [
        ("Field", "Data Type", "Description"),
        ("id", "INT (AUTO_INCREMENT, PK)", "Unique patient ID (internal)"),
        ("uuid", "CHAR(36), NOT NULL", "Universally unique patient ID"),
        ("full_name", "VARCHAR(100), NOT NULL", "Patient’s full legal name"),
        ("email", "VARCHAR(100), UNIQUE", "Patient's contact email"),
        ("contact_number", "VARCHAR(20)", "Phone or mobile number"),
        ("date_of_birth", "DATE", "Date of birth"),
        ("gender", "ENUM('Male','Female','Other')", "Gender of the patient"),
        ("address", "TEXT", "Residential or mailing address"),
        ("created_at", "TIMESTAMP, DEFAULT CURRENT_TIMESTAMP", "Patient creation date"),
    ],
    "doctor_types": [
        ("Field", "Data Type", "Description"),
        ("id", "INT (AUTO_INCREMENT, PK)", "Internal ID for doctor type"),
        ("name_type", "VARCHAR(255), NOT NULL", "Medical specialty or category (e.g. ENT)"),
        ("created_at", "TIMESTAMP", "Record creation timestamp"),
        ("updated_at", "TIMESTAMP", "Last updated timestamp"),
    ],
    "appointment": [
        ("Field", "Data Type", "Description"),
        ("id", "INT (AUTO_INCREMENT, PK)", "Internal ID for the appointment"),
        ("appointment_id", "VARCHAR(255), NOT NULL", "Unique appointment identifier"),
        ("username", "VARCHAR(50), NOT NULL", "Patient's name or identifier"),
        ("email", "VARCHAR(100)", "Patient email"),
        ("number", "VARCHAR(200), NOT NULL", "Contact number"),
        ("reason", "VARCHAR(255), NOT NULL", "Reason for the appointment"),
        ("message", "TEXT, NOT NULL", "Additional message or description"),
        ("appointment_time", "TIMESTAMP, NOT NULL", "Scheduled date and time"),
        ("status", "ENUM('Pending','Postponed','Handled')", "Current status of the appointment"),
        ("created_at", "TIMESTAMP", "Record creation date"),
        ("updated_at", "TIMESTAMP", "Last update timestamp"),
    ],
    "patient_records": [
        ("Field", "Data Type", "Description"),
        ("id", "INT (AUTO_INCREMENT, PK)", "Unique internal record ID"),
        ("record_id", "VARCHAR(255), NOT NULL", "Unique identifier for this record"),
        ("patient_id", "VARCHAR(255), NOT NULL", "Refers to patients.uuid"),
        ("record", "TEXT, NOT NULL", "Medical notes, diagnosis, etc."),
        ("updated_by", "VARCHAR(255), NOT NULL", "ID or name of the user updating record"),
        ("doctor_name", "VARCHAR(255), NOT NULL", "Doctor’s name responsible for treatment"),
        ("status", "ENUM('Under Medication','Healed','Not Diagnosed')", "Health status of patient"),
        ("created_at", "TIMESTAMP", "Record creation time"),
        ("updated_at", "TIMESTAMP", "Time when record was last modified"),
    ],
    "invoice": [
        ("Field", "Data Type", "Description"),
        ("id", "INT (AUTO_INCREMENT, PK)", "Internal invoice record ID"),
        ("invoice_id", "VARCHAR(255), NOT NULL", "Public invoice identifier"),
        ("patient_id", "VARCHAR(255), NOT NULL", "Refers to patients.uuid"),
        ("appointment_id", "VARCHAR(255), NOT NULL", "Refers to appointment.appointment_id"),
        ("amount", "DECIMAL(10,2), NOT NULL", "Total billable amount"),
        ("status", "ENUM('Pending','Paid','Cancelled')", "Payment status of the invoice"),
        ("issued_at", "TIMESTAMP, DEFAULT CURRENT_TIMESTAMP", "Time invoice was issued"),
        ("updated_at", "TIMESTAMP", "Last time the invoice was updated"),
    ],
}

# Add tables to the document
for table_name, fields in tables.items():
    doc.add_heading(table_name, level=1)
    table = doc.add_table(rows=1, cols=3)
    table.style = 'Table Grid'
    hdr_cells = table.rows[0].cells
    hdr_cells[0].text = 'Field'
    hdr_cells[1].text = 'Data Type'
    hdr_cells[2].text = 'Description'

    for row in fields[1:]:
        row_cells = table.add_row().cells
        for i, value in enumerate(row):
            row_cells[i].text = value

# Save the document
output_path = "hospital_data_dictionary.docx"
doc.save(output_path)
output_path
