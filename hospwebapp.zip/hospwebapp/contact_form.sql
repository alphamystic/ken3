-- Select or create the database
CREATE DATABASE IF NOT EXISTS hospital_db;
USE hospital_db;

-- Table creation
CREATE TABLE `contact_form` (
  `id` INT(100) NOT NULL,
  `name` VARCHAR(100) NOT NULL,
  `email` VARCHAR(100) NOT NULL,
  `number` VARCHAR(10) NOT NULL,
  `date` DATETIME NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Set primary key and auto-increment
ALTER TABLE `contact_form`
  ADD PRIMARY KEY (`id`);

ALTER TABLE `contact_form`
  MODIFY `id` INT(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
