CREATE TABLE `users` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `user_id` VARCHAR(255) NOT NULL,
  `username` VARCHAR(50) NOT NULL,
  `phone` VARCHAR(50) NOT NULL,
  `password_hash` VARCHAR(255) NOT NULL,
  `email` VARCHAR(100) UNIQUE DEFAULT NULL,
  `role` ENUM('Doctor','Receptionist','Admin','Manager','Billing') DEFAULT 'Admin',
  `gender` ENUM('Male','Female','Other') DEFAULT 'Other',
  `created_at` TIMESTAMP NULL DEFAULT current_timestamp(),
  `updated_at` TIMESTAMP NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

CREATE TABLE `patients` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `uuid` CHAR(36) NOT NULL,
  `full_name` VARCHAR(100) NOT NULL,
  `email` VARCHAR(100) UNIQUE DEFAULT NULL,
  `contact_number` VARCHAR(20) DEFAULT NULL,
  `date_of_birth` DATE DEFAULT NULL,
  `gender` ENUM('Male','Female','Other') DEFAULT NULL,
  `address` TEXT DEFAULT NULL,
  `created_at` TIMESTAMP NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

CREATE TABLE `doctor_types` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `name_type` VARCHAR(255) NOT NULL,
  `created_at` TIMESTAMP NULL DEFAULT current_timestamp(),
  `updated_at` TIMESTAMP NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

CREATE TABLE `appointment` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `appointment_id` VARCHAR(255) NOT NULL,
  `username` VARCHAR(50) NOT NULL,
  `email` VARCHAR(100) DEFAULT NULL,
  `number` VARCHAR(200) NOT NULL,
  `reason` VARCHAR(255) NOT NULL,
  `message` TEXT NOT NULL,
  `appointment_time` TIMESTAMP NOT NULL,
  `status` ENUM('Pending','Postponed','Handled') DEFAULT 'Pending',
  `created_at` TIMESTAMP NULL DEFAULT current_timestamp(),
  `updated_at` TIMESTAMP NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

CREATE TABLE `patient_records` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `record_id` VARCHAR(255) NOT NULL,
  `patient_id` VARCHAR(255) NOT NULL,
  `record` TEXT NOT NULL,
  `updated_by` VARCHAR(255) NOT NULL,
  `doctor_name` VARCHAR(255) NOT NULL,
  `status` ENUM('Under Medication','Healed','Not Diagnosed') DEFAULT 'Not Diagnosed',
  `created_at` TIMESTAMP NULL DEFAULT current_timestamp(),
  `updated_at` TIMESTAMP NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


CREATE TABLE `invoice` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `invoice_id` VARCHAR(255) NOT NULL,
  `patient_id` VARCHAR(255) NOT NULL,
  `appointment_id` VARCHAR(255) NOT NULL,
  `amount` DECIMAL(10,2) NOT NULL,
  `status` ENUM('Pending','Paid','Cancelled') DEFAULT 'Pending',
  `issued_at` TIMESTAMP DEFAULT current_timestamp(),
  `updated_at` TIMESTAMP NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
