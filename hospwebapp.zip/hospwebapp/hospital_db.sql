-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: May 26, 2025 at 08:43 AM
-- Server version: 10.4.24-MariaDB
-- PHP Version: 8.1.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `hospital_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `appointment`
--

CREATE TABLE `appointment` (
  `id` int(11) NOT NULL,
  `appointment_id` varchar(255) NOT NULL,
  `username` varchar(50) NOT NULL,
  `email` varchar(100) DEFAULT NULL,
  `number` varchar(200) NOT NULL,
  `reason` varchar(255) NOT NULL,
  `message` text NOT NULL,
  `appointment_time` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `status` enum('Pending','Postponed','Handled') DEFAULT 'Pending',
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `appointment`
--

INSERT INTO `appointment` (`id`, `appointment_id`, `username`, `email`, `number`, `reason`, `message`, `appointment_time`, `status`, `created_at`, `updated_at`) VALUES
(1, '67711efc-b753-485e-be76-ffa42c170497', 'qwe456', 'jjhgv@njkhiuh.lio', '1234567899999', 'ENT Specialist', 'wrfgerthtrerthe', '2025-05-17 21:00:00', 'Pending', '2025-05-11 06:26:02', '2025-05-25 11:51:11'),
(2, '1ac37212-03de-43ce-a720-6a60ad01a6a9', 'Sam', 'sam@mail.com', '1234567890', 'Dentist', 'ghmgnetynty', '2025-05-25 12:10:27', 'Handled', '2025-05-11 06:26:49', '2025-05-25 12:10:27'),
(3, 'a90a46c0-aecf-4ae7-95b1-6142f15a4fda', 'Arthur', 'arthur@mail.com', '1234567890', 'Oncologist', 'Wanted to see an oncologist', '2025-05-14 04:46:00', 'Pending', '2025-05-13 04:46:12', '2025-05-13 04:46:12'),
(4, 'ee74ac5f-bbf2-4e3c-ac86-054a7c8c0284', 'Sonny', 'sonny@mail.com', '1234567890', 'Dentist', 'Seeing a dentist ', '2025-05-19 06:15:00', 'Pending', '2025-05-16 05:59:55', '2025-05-16 05:59:55'),
(5, 'a8c7a484-6381-437e-994d-254d071a93ab', 'Ken', 'ken@mail.com', '1234567890', 'Neurologist', 'Have some neuron issue and need a checkup.', '2025-05-25 12:10:49', 'Handled', '2025-05-16 06:02:24', '2025-05-25 12:10:49');

-- --------------------------------------------------------

--
-- Table structure for table `doctor_types`
--

CREATE TABLE `doctor_types` (
  `id` int(11) NOT NULL,
  `name_type` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `invoice`
--

CREATE TABLE `invoice` (
  `id` int(11) NOT NULL,
  `invoice_id` varchar(255) NOT NULL,
  `patient_id` varchar(255) NOT NULL,
  `amount` decimal(10,2) NOT NULL,
  `status` enum('Pending','Paid','Cancelled') DEFAULT 'Pending',
  `issued_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `invoice`
--

INSERT INTO `invoice` (`id`, `invoice_id`, `patient_id`, `amount`, `status`, `issued_at`, `updated_at`) VALUES
(1, 'INV e8ea2661-6979-4361-af0d-c2d37a04c7e2', '6d09201e-efa0-4272-be89-cf5657f29dba', '50000.00', 'Paid', '2025-05-25 19:11:15', '2025-05-25 19:11:15'),
(2, 'INV 7deec87b-5ca0-4905-af26-a9f452d0ecb0', '96073b47-1e81-4160-a806-ce18f1366364', '100000.00', 'Pending', '2025-05-25 19:25:08', '2025-05-25 19:25:08'),
(3, 'INV 6f862769-73a7-41eb-81d6-0f9d5692d5d2', 'ee6659fd-24ac-4147-ac2a-c340e8c12fef', '700000.00', 'Pending', '2025-05-25 19:27:10', '2025-05-25 19:27:10'),
(4, 'INV 36c89a2a-28a1-4f56-8f29-f0278234350c', 'ff2746df-c72e-40dc-b9c0-86268981410f', '1000000.00', 'Pending', '2025-05-25 19:44:03', '2025-05-25 19:44:03'),
(5, 'INV 1ee0612e-11d5-4361-9e9c-9902a5a8d889', 'ff2746df-c72e-40dc-b9c0-86268981410f', '1000000.00', 'Pending', '2025-05-26 05:14:29', '2025-05-26 05:14:29');

-- --------------------------------------------------------

--
-- Table structure for table `patients`
--

CREATE TABLE `patients` (
  `id` int(11) NOT NULL,
  `uuid` char(36) NOT NULL,
  `full_name` varchar(100) NOT NULL,
  `email` varchar(100) DEFAULT NULL,
  `contact_number` varchar(20) DEFAULT NULL,
  `date_of_birth` date DEFAULT NULL,
  `gender` enum('Male','Female','Other') DEFAULT NULL,
  `address` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `patients`
--

INSERT INTO `patients` (`id`, `uuid`, `full_name`, `email`, `contact_number`, `date_of_birth`, `gender`, `address`, `created_at`) VALUES
(1, '6d09201e-efa0-4272-be89-cf5657f29dba', 'Ken Lumumba', 'ken@mail.com', '12345678', '2025-05-15', 'Male', '123456', '2025-05-25 04:24:03'),
(4, '96073b47-1e81-4160-a806-ce18f1366364', 'Test Patient33', 'testpatient@mail.com', '123456789', '2025-05-20', 'Female', '12345678', '2025-05-25 07:37:20'),
(5, 'ee6659fd-24ac-4147-ac2a-c340e8c12fef', 'Other Patient', 'otherp@mail.com', '23456789', '2025-05-09', 'Male', 'Melbourne 4th St', '2025-05-25 07:38:11'),
(6, 'ff2746df-c72e-40dc-b9c0-86268981410f', 'Sonny Ken', 'sonnykenny@mail.com', '12345678', '2000-12-01', 'Male', '2025-05-10', '2025-05-25 19:43:43');

-- --------------------------------------------------------

--
-- Table structure for table `patient_records`
--

CREATE TABLE `patient_records` (
  `id` int(11) NOT NULL,
  `record_id` varchar(255) NOT NULL,
  `patient_id` varchar(255) NOT NULL,
  `record` text NOT NULL,
  `updated_by` varchar(255) NOT NULL,
  `doctor_name` varchar(255) NOT NULL,
  `status` enum('Under Medication','Healed','Not Diagnosed') DEFAULT 'Not Diagnosed',
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `patient_records`
--

INSERT INTO `patient_records` (`id`, `record_id`, `patient_id`, `record`, `updated_by`, `doctor_name`, `status`, `created_at`, `updated_at`) VALUES
(1, '15317ea4-83b5-4473-aad8-9e81e53ab8dd', '6d09201e-efa0-4272-be89-cf5657f29dba', 'Cancer', 'Murdoc', 'Murdoc', 'Under Medication', '2025-05-25 09:26:20', '2025-05-25 09:26:20'),
(2, '00ff376d-45d3-49eb-9ac3-69f7da54f5ff', 'ee6659fd-24ac-4147-ac2a-c340e8c12fef', 'Tuberculosis', 'Receptionist', 'Mneuomonae', 'Under Medication', '2025-05-25 09:35:34', '2025-05-25 09:35:34'),
(3, '9e652588-6287-46ad-9ed6-016fdfeaa05d', '6d09201e-efa0-4272-be89-cf5657f29dba', 'Colonoscopy', '73bb1cc0-25b0-4be5-9d1b-57b73673ffcf', 'Appendix', 'Under Medication', '2025-05-26 05:21:30', '2025-05-26 05:21:30'),
(4, '59337d01-5e41-4e08-9af2-2124e623fd74', '6d09201e-efa0-4272-be89-cf5657f29dba', 'Flu', '73bb1cc0-25b0-4be5-9d1b-57b73673ffcf', 'Flu Doc', 'Healed', '2025-05-26 05:22:31', '2025-05-26 05:22:31');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `user_id` varchar(255) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password_hash` varchar(255) NOT NULL,
  `email` varchar(100) DEFAULT NULL,
  `role` enum('Doctor','Receptionist','Admin','Manager','Billing') DEFAULT 'Admin',
  `gender` enum('Male','Female','Other') DEFAULT 'Other',
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `user_id`, `username`, `password_hash`, `email`, `role`, `gender`, `created_at`, `updated_at`) VALUES
(1, '73bb1cc0-25b0-4be5-9d1b-57b73673ffcf', 'Samuel', '$2a$10$XaGY5aXiP0lshlLcIra0meYPiLEy.BY5W4Wr9kpl2Id73839W2OIe', 'sam@mail.com', 'Doctor', 'Male', '2025-05-11 16:21:00', '2025-05-11 16:21:00'),
(2, '0ee2f9be-b6c9-4522-acc9-f6de41d656e7', 'Testmobile', '$2a$10$92mCpVwS1p912UMb2vNNXOlZwJW8giwbS8Kbt98MQhB/nmeh39mN2', 'mobile@mobile.com', 'Receptionist', 'Male', '2025-05-13 05:48:35', '2025-05-13 05:48:35'),
(3, '31bc02bc-6718-477a-9410-55b446d5c854', 'tester', '$2a$10$f8s8mM51P1bR6pMGhO0fuen2G2cdmuMMYQko7O92uhyGNdzVnE5I6', 'test@mail.com', 'Receptionist', 'Female', '2025-05-18 13:33:28', '2025-05-18 13:33:28'),
(4, 'fd7dda78-3811-465e-885a-08bc33c03871', 'Receptionist', '$2a$10$9mLZHPq65laGZko.CUVJfu9dfzDffC2RUmoxibQiASNBXhQe5fQIy', 'reception@mail.com', 'Receptionist', 'Female', '2025-05-23 16:28:02', '2025-05-23 16:28:02');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `appointment`
--
ALTER TABLE `appointment`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `doctor_types`
--
ALTER TABLE `doctor_types`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `invoice`
--
ALTER TABLE `invoice`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `patients`
--
ALTER TABLE `patients`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Indexes for table `patient_records`
--
ALTER TABLE `patient_records`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `appointment`
--
ALTER TABLE `appointment`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `doctor_types`
--
ALTER TABLE `doctor_types`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `invoice`
--
ALTER TABLE `invoice`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `patients`
--
ALTER TABLE `patients`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `patient_records`
--
ALTER TABLE `patient_records`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
