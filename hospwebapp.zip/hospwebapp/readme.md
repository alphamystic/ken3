# MEDTRUST Hospital
### 🎯 1. Introduction
Welcome to the Hospital Appointment Booking System. This system allows hospital staff to manage users, patients, and appointments efficiently through a clean web interface with dynamic interaction powered by AJAX.
Medtrust Appointment booking system is a simple lightweight web application that allows the booking of appointments online. A receptionist can then reschedule an appointment
or create a patient for them to be treated by the doctor and add patient record. This allows for proper record keeping. The system is designed in golang to allow for scalability
say into a hospital management system.

✅ **Advantages of Golang over PHP in Your System**

| Advantage                  | Description |
| -------------------------- | ---------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| **Performance**            | Golang is statically typed and compiled, leading to faster execution and lower latency. This is ideal for real-time systems like appointment rescheduling or status updates. |
| **Concurrency**            | Go’s goroutines make it easy to handle thousands of concurrent users — perfect for handling multiple patient bookings or async tasks.                                        |
| **Memory Management**      | Go has efficient garbage collection and low memory footprint, which benefits long-running processes like caching with Redis.                                                 |
| **Scalability**            | Designed with microservices and performance in mind, Go scales better than PHP for large-scale systems.                                                                      |
| **Static Typing & Safety** | Better type safety and fewer runtime surprises compared to dynamically typed PHP.|

Golang having no templating engine, we built a lightweight loader from scratch and called it template_loader, it loads all the templates from file
and strores the base ones in a Handler, the rest are loaded on request. This gives an advantage of loading frnt end functionalities without having
to restart the server. This can also be loaded and cached in a reddis server then trigger a reload on file edit.

🧾 **User Manual for the Hospital Appointment Booking System**
### 📁 2. System Structure (Domain Driven Design)

#### 🔧 Core Modules:

| Module                     | Description |
| -------------------------- | ---------------------------------------------------------------------------------------------------------------------------------------- |
| **Domain**                 | Holds core business logic with `list`, `create`, `update`, and `delete` functions for each entity (e.g., users, appointments, patients). |
| **Domain (Persistence Layer)** | Manages all DB interactions. Separate modules like `exec` are used to store and run parameterized queries.                               |
| **Entities**               | Define the core data structures: `User`, `Patient`, `Invoice`, `Appointment`.                                                            |
| **DBConnector**            | Singleton connection manager for MongoDB or Redis. Ensures connection reuse and central config management.                               |
| **Exec**                  | Stores the queries to be used by the different domain functions to persist data to or from the DM.                                       |

### 🎨 3. User Interface (UI Layer)

| Component    | Description                                                                        |
| ------------ | ---------------------------------------------------------------------------------- |
| **Handlers** | Process HTTP requests, validate data, and call domain logic.                       |
| **Router**   | Manages routing (e.g., `/login`, `/scheduleappointment`, `/listpatients`).                          |
| **Static**   | Stores CSS, JS, and image files, which are cached on initial load for performance. |
| **Tmpl**     | Template folder for HTML views (uses PHP template includes or blade-like syntax).  |

### ⚙️ 4. Utilities

| Utility                   | Purpose                                                                         |
| ------------------------- | ------------------------------------------------------------------------------- |
| `generateUUID()`          | Generates a unique identifier for new records (e.g., patients or appointments). |
| `colorPrint(text, color)` | Debug utility for printing colored logs or messages.                            |
| `Logging`                 | Implements logging functionalities of the various errors                        |

### 🧠 5. Suggested Enhancements (Caching & Performance)

**Redis Usage Ideas:**
- Cache reschedule options per doctor.
- Cache upcoming appointments (expiring in 1 hour).
- Store login/session data to reduce DB calls.
- Track failed login attempts for throttling.

**MongoDB Usage Ideas:**
- Store audit logs, messages, or semi-structured health records.
- Save dynamic patient interactions or historical appointment states.

### 👨‍⚕️ 6. System Features

#### 🔐 Authentication
- Register a user with role (admin/staff).
- Login using email/password.
- Sessions handled via cookies and server sessions (or Redis).

#### 📅 Appointments
- Create new appointments: select patient, doctor type, date, and time.
- List all appointments or filter by status/date.
- Reschedule or cancel appointments via AJAX form.
- Validate double booking or time conflicts.

#### 👥 Patients Management
- Add new patient with full details (name, age, history).
- Edit or delete patient records, done by a doctor.
- Search by name, ID, or contact.

#### 🧾 Invoices
A receptionist functionality to create an invoice before or after a patient has been served.
- Generate invoice after appointment.
- List and manage invoice payments.

### 💡 7. Admin and Developer Notes
- Code organized using DDD (Domain Driven Design) for modular development.
- Each module is self-contained and testable.
- AJAX usage allows smooth page updates without full reloads.
- Future support for message queue integration (e.g., background appointment reminders).

### 📌 8. Deployment Checklist

| Task                              | Status           |
| --------------------------------- | ---------------- |
| Golang runtime installed          | ✅                |
| Mysql Database installed          | ✅                |
| MongoDB/Redis configured          | ✅                |
| Static file caching enabled       | ✅                |
| HTTPS (SSL) setup                 | ☐                |
| Error handling/logging            | ✅ (with `utils`) |
| Daily database backup script      | ☐                |
| Email/SMS service (for reminders) | ☐                |


### TODOs
1. Map routes for each user
2. Create,List and update patient and patient records.
3. Implement Forgot Password Functionality
4. Add Dosage functionalities to track patient medicine prescribed.
5. Generate and list invoices.
