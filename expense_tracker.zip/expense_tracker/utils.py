from datetime import datetime

def validate_amount(input_str):
    try:
        return float(input_str)
    except ValueError:
        raise ValueError("Invalid amount. Please enter a number.")

def validate_date(input_str):
    try:
        datetime.strptime(input_str, '%Y-%m-%d')
        return input_str
    except ValueError:
        raise ValueError("Invalid date format. Use YYYY-MM-DD.")
