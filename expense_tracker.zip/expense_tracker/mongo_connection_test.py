from pymongo.mongo_client import MongoClient
from pymongo.server_api import ServerApi

## Connect to Google Account
# uri = "mongodb+srv://kennymit42:XZ2KwB9ATw2pJQEN@clusterkennedy.158irqs.mongodb.net/?retryWrites=true&w=majority&appName=ClusterKennedy"
# uri = "mongodb://localhost:27017/")

# Create a new client and connect to the server
client = MongoClient(uri, server_api=ServerApi('1'))

# Send a ping to confirm a successful connection

try:
    client.admin.command('ping')
    print("Pinged your deployment. You successfully connected to MongoDB!")
except Exception as e:
    print(e)
