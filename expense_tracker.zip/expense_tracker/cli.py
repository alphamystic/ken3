import sys
from datetime import datetime
from utils import validate_amount, validate_date

if len(sys.argv) < 2 or sys.argv[1] not in ('mongo', 'redis'):
    print("Usage: python cli.py [mongo|redis]")
    sys.exit(1)

backend_type = sys.argv[1]
if backend_type == 'mongo':
    import mongo_backend as backend
else:
    import redis_backend as backend

def print_menu():
    print("\nExpense Tracker")
    print("1. Add Expense")
    print("2. View All Expenses")
    print("3. Update Expense")
    print("4. Delete Expense")
    print("5. Total by Date")
    print("6. Total by Category")
    print("7. Exit")

def get_expense_input():
    description = input("Description: ")
    amount = validate_amount(input("Amount: "))
    category = input("Category: ")
    date = validate_date(input("Date (YYYY-MM-DD): "))
    return {"description": description, "amount": amount, "category": category, "date": date}

while True:
    print_menu()
    choice = input("Choose an option: ")

    if choice == '1':
        expense = get_expense_input()
        expense_id = backend.add_expense(expense)
        print("Expense added with ID:", expense_id)

    elif choice == '2':
        for exp in backend.get_all_expenses():
            print(exp)

    elif choice == '3':
        eid = input("Expense ID to update: ")
        print("Leave field blank to skip update")
        updated = {}
        desc = input("New Description: ")
        if desc: updated['description'] = desc
        amt = input("New Amount: ")
        if amt: updated['amount'] = validate_amount(amt)
        cat = input("New Category: ")
        if cat: updated['category'] = cat
        dt = input("New Date (YYYY-MM-DD): ")
        if dt: updated['date'] = validate_date(dt)
        result = backend.update_expense(eid, updated)
        print("Updated." if result else "Failed to update.")

    elif choice == '4':
        eid = input("Expense ID to delete: ")
        result = backend.delete_expense(eid)
        print("Deleted." if result else "Failed to delete.")

    elif choice == '5':
        dt = validate_date(input("Enter date (YYYY-MM-DD): "))
        print("Total spent:", backend.get_total_by_date(dt))

    elif choice == '6':
        cat = input("Enter category: ")
        print("Total spent:", backend.get_total_by_category(cat))

    elif choice == '7':
        print("Goodbye!")
        break

    else:
        print("Invalid choice. Try again.")
