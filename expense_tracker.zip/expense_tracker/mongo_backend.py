import pymongo
from bson.objectid import ObjectId

def connect():
    client = pymongo.MongoClient("mongodb://localhost:27017/")
    db = client["expense_tracker"]
    return db["expenses"]

def add_expense(expense):
    collection = connect()
    return collection.insert_one(expense).inserted_id

def get_all_expenses():
    collection = connect()
    return list(collection.find())

def update_expense(expense_id, updated_fields):
    collection = connect()
    return collection.update_one({"_id": ObjectId(expense_id)}, {"$set": updated_fields})

def delete_expense(expense_id):
    collection = connect()
    return collection.delete_one({"_id": ObjectId(expense_id)})

def get_total_by_date(date):
    collection = connect()
    pipeline = [
        {"$match": {"date": date}},
        {"$group": {"_id": "$date", "total": {"$sum": "$amount"}}}
    ]
    result = list(collection.aggregate(pipeline))
    return result[0]["total"] if result else 0

def get_total_by_category(category):
    collection = connect()
    pipeline = [
        {"$match": {"category": category}},
        {"$group": {"_id": "$category", "total": {"$sum": "$amount"}}}
    ]
    result = list(collection.aggregate(pipeline))
    return result[0]["total"] if result else 0
