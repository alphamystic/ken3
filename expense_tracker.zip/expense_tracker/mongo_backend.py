import pymongo
from pymongo.mongo_client import MongoClient
from bson.objectid import ObjectId
from pymongo.server_api import ServerApi

def connect():
    #client = pymongo.MongoClient("mongodb://localhost:27017/")
    uri = "mongodb+srv://kennymit42:XZ2KwB9ATw2pJQEN@clusterkennedy.158irqs.mongodb.net/?retryWrites=true&w=majority&appName=ClusterKennedy"
    client = MongoClient(uri, server_api=ServerApi('1'))
    db = client["expense_tracker"]
    return db["expenses"]

def add_expense(expense):
    collection = connect()
    return collection.insert_one(expense).inserted_id

def get_all_expenses():
    collection = connect()
    return list(collection.find())

def update_expense(expense_id, updated_fields):
    collection = connect()
    return collection.update_one({"_id": ObjectId(expense_id)}, {"$set": updated_fields})

def delete_expense(expense_id):
    collection = connect()
    return collection.delete_one({"_id": ObjectId(expense_id)})

def get_total_by_date(date):
    collection = connect()
    pipeline = [
        {"$match": {"date": date}},
        {"$group": {"_id": "$date", "total": {"$sum": "$amount"}}}
    ]
    result = list(collection.aggregate(pipeline))
    return result[0]["total"] if result else 0

def get_total_by_category(category):
    collection = connect()
    pipeline = [
        {"$match": {"category": category}},
        {"$group": {"_id": "$category", "total": {"$sum": "$amount"}}}
    ]
    result = list(collection.aggregate(pipeline))
    return result[0]["total"] if result else 0

def get_total_all():
    collection = connect()
    pipeline = [
        {"$group": {"_id": None, "total": {"$sum": "$amount"}}}
    ]
    result = list(collection.aggregate(pipeline))
    return result[0]["total"] if result else 0


#
# from pymongo.mongo_client import MongoClient
# from pymongo.server_api import ServerApi
#
# ## Connect to Google Account
# uri = "mongodb+srv://kennymit42:XZ2KwB9ATw2pJQEN@clusterkennedy.158irqs.mongodb.net/?retryWrites=true&w=majority&appName=ClusterKennedy"
#
#
# # Create a new client and connect to the server
# client = MongoClient(uri, server_api=ServerApi('1'))
#
# # Send a ping to confirm a successful connection
#
# try:
#     client.admin.command('ping')
#     print("Pinged your deployment. You successfully connected to MongoDB!")
# except Exception as e:
#     print(e)
