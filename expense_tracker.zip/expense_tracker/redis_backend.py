import redis
import uuid
import json



def connect_to_redis():
# Create a connection to the Redis database
    host='redis-13551.c291.ap-southeast-2-1.ec2.redns.redis-cloud.com';
    port=13551;  # Default Redis port
    username="default";
    password="ZZeFParrF24iCXBlGYx2SckqVQwgATp8";

    return redis.StrictRedis(host=host, port=port, username=username, password=password, decode_responses=True)

# r = redis.Redis(host='localhost', port=6379, db=0)

r = connect_to_redis()
def add_expense(expense):
    expense_id = str(uuid.uuid4())
    r.set(f"expense:{expense_id}", json.dumps(expense))
    r.sadd(f"expense_by_date:{expense['date']}", expense_id)
    r.sadd(f"expense_by_category:{expense['category']}", expense_id)
    return expense_id

def get_all_expenses():
    keys = r.keys("expense:*")
    return [{"id": key.split(":")[1], **json.loads(r.get(key))} for key in keys]

def update_expense(expense_id, updated_fields):
    key = f"expense:{expense_id}"
    if not r.exists(key):
        return False
    expense = json.loads(r.get(key))
    expense.update(updated_fields)
    r.set(key, json.dumps(expense))
    return True

def delete_expense(expense_id):
    key = f"expense:{expense_id}"
    if not r.exists(key):
        return False
    expense = json.loads(r.get(key))
    r.delete(key)
    r.srem(f"expense_by_date:{expense['date']}", expense_id)
    r.srem(f"expense_by_category:{expense['category']}", expense_id)
    return True

def get_total_by_date(date):
    ids = r.smembers(f"expense_by_date:{date}")
    total = 0
    for eid in ids:
        expense = json.loads(r.get(f"expense:{eid}"))  # No .decode()
        total += float(expense["amount"])
    return total

def get_total_by_category(category):
    ids = r.smembers(f"expense_by_category:{category}")
    total = 0
    for eid in ids:
        expense = json.loads(r.get(f"expense:{eid}"))  # No .decode()
        total += float(expense["amount"])
    return total
