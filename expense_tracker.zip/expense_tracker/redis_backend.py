import redis
import uuid
import json



def connect_to_redis():
    #Create a connection to the Redis database
    host='redis-13551.c291.ap-southeast-2-1.ec2.redns.redis-cloud.com';
    port=13551;  # Default Redis port
    username="default";
    password="ZZeFParrF24iCXBlGYx2SckqVQwgATp8";
    return redis.StrictRedis(host=host, port=port, username=username, password=password, decode_responses=True)
    #return redis.Redis(host='localhost', port=6379, db=0)

# r = redis.Redis(host='localhost', port=6379, db=0)

r = connect_to_redis()

def decode_bytes(val):
    return val.decode() if isinstance(val, bytes) else val

def add_expense(expense):
    expense_id = str(uuid.uuid4())
    r.set(f"expense:{expense_id}", json.dumps(expense))
    r.sadd(f"expense_by_date:{expense['date']}", expense_id)
    r.sadd(f"expense_by_category:{expense['category']}", expense_id)
    return expense_id

def get_all_expenses():
    keys = r.keys("expense:*")
    expenses = []
    for key in keys:
        key_str = decode_bytes(key)
        if key_str.startswith("expense_by_"):
            continue
        raw = r.get(key)
        raw = decode_bytes(raw)
        data = json.loads(raw)
        expenses.append({"id": key_str.split(":")[1], **data})
    return expenses

def update_expense(expense_id, updated_fields):
    key = f"expense:{expense_id}"
    if not r.exists(key):
        return False
    expense_raw = decode_bytes(r.get(key))
    expense = json.loads(expense_raw)
    expense.update(updated_fields)
    r.set(key, json.dumps(expense))
    return True

def delete_expense(expense_id):
    key = f"expense:{expense_id}"
    if not r.exists(key):
        return False
    expense_raw = decode_bytes(r.get(key))
    expense = json.loads(expense_raw)
    r.delete(key)
    r.srem(f"expense_by_date:{expense['date']}", expense_id)
    r.srem(f"expense_by_category:{expense['category']}", expense_id)
    return True

def get_total_by_date(date):
    ids = r.smembers(f"expense_by_date:{date}")
    total = 0
    for eid in ids:
        eid_str = decode_bytes(eid)
        expense_raw = decode_bytes(r.get(f"expense:{eid_str}"))
        expense = json.loads(expense_raw)
        total += float(expense["amount"])
    return total

def get_total_by_category(category):
    ids = r.smembers(f"expense_by_category:{category}")
    total = 0
    for eid in ids:
        eid_str = decode_bytes(eid)
        expense_raw = decode_bytes(r.get(f"expense:{eid_str}"))
        expense = json.loads(expense_raw)
        total += float(expense["amount"])
    return total

def get_total_all():
    keys = r.keys("expense:*")
    total = 0
    for key in keys:
        key_str = decode_bytes(key)
        if key_str.startswith("expense_by_"):
            continue
        expense_raw = decode_bytes(r.get(key))
        expense = json.loads(expense_raw)
        total += float(expense["amount"])
    return total
